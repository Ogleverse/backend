<?php

use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\BalanceController;
use App\Http\Controllers\GameController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\KabanchikController;
use App\Http\Controllers\RegistrationController;
use App\Http\Controllers\ShopItemController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\WalletController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['json.response', 'auth:web'])->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['middleware' => 'json.response', 'prefix' => 'auth'], function () {
    Route::post('/reset-password', [PasswordResetLinkController::class, 'store']);
    Route::post('/reset/password', [NewPasswordController::class, 'store']);

	Route::post('/register', [RegistrationController::class, 'register']);
	Route::get('/register/ref/{code}', [RegistrationController::class, 'registerRef']);
     Route::post('/login', [LoginController::class, 'login']);
     Route::post('/logout', [LoginController::class, 'logout'])->middleware(['auth:sanctum']);
     Route::get('/status', [LoginController::class, 'status'])->middleware(['auth:sanctum']);
});

Route::group(['middleware' => ['json.response', 'auth:sanctum']], function() {
    if (env('APP_DEBUG')) {
      Route::get('test-coin', [GameController::class, 'getTestCoin']);
    }
    Route::apiResource('games', GameController::class);
    Route::get('transactions/stats', [TransactionController::class, 'stats']);
    Route::apiResource('transactions', TransactionController::class);
    Route::get('game', [GameController::class, 'showCurrentGame']);
    Route::post('game/join', [GameController::class, 'join']);

    Route::post('kabanchik/buy', [KabanchikController::class, 'buy']);
    Route::post('kabanchiks/{id}/pop', [KabanchikController::class, 'pop']);
    Route::get('kabanchiks/{id}/transactions', [TransactionController::class, 'showByKabanchik']);
    Route::get('kabanchiks/{id}/chart', [TransactionController::class, 'showChartByKabanchik']);
    Route::apiResource('kabanchiks', KabanchikController::class);



    Route::get('wallet', [WalletController::class, 'info']);
    Route::post('wallet/replenish', [WalletController::class, 'replenish']);
    Route::post('wallet/withdraw', [WalletController::class, 'withdraw']);
    // Route::get('wallet/exchange', [WalletController::class, 'getExchangeRates']);
    // Route::post('wallet/exchange', [WalletController::class, 'exchange']);

    Route::post('shop/buy', [ShopItemController::class, 'buy']);
    Route::apiResource('shop', ShopItemController::class);
});
Route::post('wallet/{secret}', [WalletController::class, 'webHook'])->middleware(['json.response']);
