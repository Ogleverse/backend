<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\KabanchikSkin;

class KabanchikSkinSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $skins = [
            [
                'name' => 'crackedegg',
                'image' => 'egg_cracked.png'
            ],
            [
                'name' => 'egg1',
                'image' => 'egg1.png'
            ],
            [
                'name' => 'egg2',
                'image' => 'egg2.png'
            ],
            [
                'name' => 'egg3',
                'image' => 'egg3.png'
            ],
            [
                'name' => 'egg4',
                'image' => 'egg4.png'
            ]
        ];
        for ($i=1; $i <= 56; $i++) {
            $skins []= [
                'name' => 'c'.$i,
                'image' => 'c'.$i.'.png',
            ];
        }
        for ($i=1; $i <= 21; $i++) {
            $skins []= [
                'name' => 'p'.$i,
                'image' => 'p'.$i.'.png',
            ];
        }
        KabanchikSkin::insert($skins);
    }
}
