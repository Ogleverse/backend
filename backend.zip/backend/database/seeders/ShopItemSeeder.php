<?php

namespace Database\Seeders;

use App\Models\KabanchikSkin;
use App\Models\ShopItem;
use Illuminate\Database\Seeder;

class ShopItemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ShopItem::insert([
            [
                'type' => 'egg',
                'data' => '{"next_level":1,"next_level_experience":100,"value":"0.000005","hidden_value":"0.000005","type":"egg"}',
                'name' => 'Egg Lvl1',
                'image' => 'egg1.png',
                'price_bnb' => '0.00001',
                'description' => 'Basic kabanchik egg. Hatches into lvl1 kabanchik'
            ],
            [
                'type' => 'egg',
                'data' => '{"next_level":3,"next_level_experience":360,"value":"0.00002","hidden_value":"0.00002","type":"egg"}',
                'name' => 'Egg Lvl3',
                'image' => 'egg2.png',
                'price_bnb' => '0.00004',
                'description' => 'Beginner\'s kabanchik egg. Hatches into lvl3 kabanchik'
            ],
            [
                'type' => 'egg',
                'data' => '{"next_level":5,"next_level_experience":720,"value":"0.000075","hidden_value":"0.000075","type":"egg"}',
                'name' => 'Egg Lvl5 A',
                'image' => 'egg3.png',
                'price_bnb' => '0.00015',
                'description' => 'Dominator kabanchik egg. Hatches into lvl5 kabanchik'
            ],
            [
                'type' => 'egg',
                'data' => '{"next_level":5,"next_level_experience":720,"value":"0.000075","hidden_value":"0.000075","type":"egg"}',
                'name' => 'Egg Lvl5 B',
                'image' => 'egg4.png',
                'price_bnb' => '0.00015',
                'description' => 'Master kabanchik egg. Hatches into lvl5 kabanchik'
            ],
        ]);
    }
}
