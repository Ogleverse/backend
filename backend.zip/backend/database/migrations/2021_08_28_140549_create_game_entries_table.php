<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGameEntriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('game_entries', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignId('game_id')
                  ->references('id')->on('games')
                  ->onDelete('cascade');
            $table->foreignId('user_id')
                  ->references('id')->on('users')
                  ->onDelete('cascade');
            $table->foreignId('kabanchik_id')
                  ->references('id')->on('kabanchiks')
                  ->onDelete('cascade');
            $table->string('type', 16);
            $table->decimal('deposit', 24, 8);
            $table->decimal('expects', 24, 8);
            $table->decimal('risk', 24, 8);
            $table->decimal('result', 24, 8);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('game_entries');
    }
}
