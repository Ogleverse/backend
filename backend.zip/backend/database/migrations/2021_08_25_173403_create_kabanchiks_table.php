<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateKabanchiksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kabanchiks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')
                  ->references('id')->on('users')
                  ->onDelete('restrict');
            $table->foreignId('kabanchik_skin_id')
                  ->references('id')->on('kabanchik_skins')
                  ->onDelete('restrict');
            $table->boolean('is_locked')->default('1');
            $table->string("type", 16);
            $table->integer('level');
            $table->integer('experience')->default(0);
            $table->integer('next_level_experience')->default(0);
            $table->decimal('value', 34, 18);
            $table->decimal('hidden_value', 34, 18)->default(0);
            $table->decimal('value_limit', 34, 18)->default(0);
            $table->decimal('top_value', 34, 18)->default(0);
            $table->decimal('risk', 24, 8)->default(0);
            $table->decimal('zone_bonus', 4, 3)->default(0.000);
            $table->string('rarity', 16)->default('common');
            $table->string('collection', 16)->nullable();
            $table->boolean('top_greed_last_round')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('kabanchiks');
    }
}
