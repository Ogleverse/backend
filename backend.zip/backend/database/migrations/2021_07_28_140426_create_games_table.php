<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateGamesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('games', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->timestamp('can_act_before');
            $table->timestamp('ends_at');
            $table->unsignedBigInteger('total_bids')->default(0);
            $table->float('total_pool', 32, 8)->default(0);
            $table->timestamp('cached_at')->nullable();
            $table->boolean('is_ended')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('games');
    }
}
