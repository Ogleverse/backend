<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShopItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shop_items', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->string('type', 16);
            $table->string('data', 255);
            $table->string('name', 200)->unique();
            $table->string('image', 200);
            $table->decimal('price_bnb', 34, 18)->nullable();
            $table->decimal('discount_price_bnb', 34, 18)->nullable();
            $table->decimal('price_oglc', 34, 18)->nullable();
            $table->decimal('discount_price_oglc', 34, 18)->nullable();
            $table->text('description');
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shop_items');
    }
}
