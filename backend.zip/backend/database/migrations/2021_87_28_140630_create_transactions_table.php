<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->timestamps();
            $table->foreignId('user_id')
                  ->nullable()
                  ->references('id')->on('users')
                  ->onDelete('cascade');
            $table->foreignId('kabanchik_id')
                  ->nullable()
                  ->references('id')->on('kabanchiks')
                  ->onDelete('cascade');
            $table->foreignId('game_id')
                  ->nullable()
                  ->references('id')->on('games')
                  ->onDelete('cascade');
            $table->foreignId('game_entry_id')
                  ->nullable()
                  ->references('id')->on('game_entries')
                  ->onDelete('cascade');
            $table->decimal('amount', 34, 18);
            $table->string('currency', 8)->default('oglc');
            $table->string('type', 16);
            // $table->enum('type', [
            //     'replenishment',
            //     'withdrawal',
            //     'bet',
            //     'win',
            //     'kabanchik_bet',
            //     'kabanchik_win',
            //     'buy_kabanchik',
            //     'pop_kabanchik',
            //     'buy',
            //     'sell',
            //     'rounding_error',
            //     'fee',
            //     ]);
            $table->enum('status', ['new', 'pending', 'success', 'fail'])->default('pending');
            $table->string('comment', 128)->nullable();
            //
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
