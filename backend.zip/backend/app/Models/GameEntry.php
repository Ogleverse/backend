<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GameEntry extends Model
{
    use HasFactory;

    protected $guarded = [];

    // protected $appends = ['expects', 'delta', 'greed'];

    public $delta = 0.0;
    public $greed = 0.0;
    public $bet = 0.0;
    public $constExpects = false;
    public $expectsLogWindow = 0.0;
    public $betLogWindow = 0.0;

    public function game() {
        return $this->belongsTo(Game::class);
    }

    public function user() {
        return $this->belongsTo(User::class);
    }

    public function kabanchik() {
        return $this->belongsTo(Kabanchik::class);
    }
}
