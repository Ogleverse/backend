<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Casts\AsArrayObject;

class ShopItem extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $guarded = [];
    protected $fillable = [
        'type',
        'data',
        'name',
        'image',
        'price_bnb',
        'discount_price_bnb',
        'price_oglc',
        'discount_price_oglc',
        'description',
    ];

    protected $casts = [
        'data' => AsArrayObject::class
    ];
}
