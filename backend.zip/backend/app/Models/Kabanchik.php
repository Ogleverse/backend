<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kabanchik extends Model
{
    use HasFactory;

    public $isFlagged = false;
    public $receivedXp = 0;

    protected $guarded = [];

    // protected $fillable = [
    //     'user_id',
    //     'kabanchik_skin_id',
    //     'level',
    //     'experience',
    //     'type',
    //     'next_level_experience',
    //     'multiplier',
    //     'value',
    //     'top_value'
    // ];

    public function kabanchikSkin()
    {
        return $this->belongsTo(KabanchikSkin::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
