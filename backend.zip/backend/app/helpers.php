<?php

use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

if (!function_exists('jsonResponse')) {
	function jsonResponse($data = null, $statusCode = 200, $message = 'Request completed successfully', $errors = null, \Illuminate\Http\Request $request = null): JsonResponse
	{
		$responseData = [
			'success' => ((int)($statusCode/100) == 2),
			'message' => $message,
		];

		if ($data instanceof \Illuminate\Http\Resources\Json\JsonResource) {
			$data->additional($responseData);

			return $data->toResponse($request)->setStatusCode($statusCode);
		}

		if (!empty($data)) {
			$responseData['data'] = $data;
		}

		if (!empty($errors)) {
			$responseData['errors'] = $errors;
		}

		return response()->json($responseData, $statusCode, [
			'Content-Type' => 'application/json;charset=UTF-8',
			'Charset' => 'utf-8'
		], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
	}
}

function amount2wei($amount)
{
	bcscale(18);
	$result = bcmul($amount, bcpow('10', '18'));
	bcscale(0);
	return bcadd($result, 0);
}

function wei2amount($wei)
{
	bcscale(18);
	return bcdiv($wei, bcpow('10', '18'));
}

function riskToMultiplier($risk)
{
	return 1 + $risk;
}

function transactionDataToArray($string)
{
	$chunks = explode(',', $string);
	$data = [];
	foreach ($chunks as &$chunk) {
		$kvpair = explode(':', $chunk, 2);
		if (count($kvpair) < 2) continue;
		$data[$kvpair[0]] = $kvpair[1];
	}
	return $data;
}

bcscale(18);
