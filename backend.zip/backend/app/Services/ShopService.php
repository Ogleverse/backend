<?php

namespace App\Services;
use App\Services\WalletService;
use App\Services\WebsocketService;
use App\Services\KabanchikGameService;
use App\Models\Kabanchik;
use App\Models\User;
use App\Models\ShopItem;
use App\Models\Transaction;
use App\Exceptions\InsufficientBNBException;
use App\Exceptions\InsufficientOGLCException;
use \Exception;

class ShopService
{
    function __construct(WalletService $walletService, KabanchikGameService $kabanchikGameService, WebsocketService $websocketService)
    {
        $this->walletService = $walletService;
        $this->kabanchikGameService = $kabanchikGameService;
        $this->websocketService = $websocketService;
    }

    /**
     * Try to buy an item for OGLC. In case there's not enough OGLC, try to exchange BNB to OGLC and buy later
     * @param  User     $user     User that wants to buy an item
     * @param  ShopItem $shopItem Item to buy
     * @return Transaction        Buy for OGLC transaction or an exchange transaction
     * @throws InsufficientOGLCException Insufficient OGLC balance
     * @throws InsufficientBNBException Insufficient BNB balance
     */
    function buyForBnb(User $user, ShopItem $shopItem): Transaction
    {
        if ($shopItem->type == 'egg') {
            $pendingTransactions = Transaction::where([
                ['user_id', '=', $user->id],
                ['type', '=', 'buy'],
                ['status', '=', 'pending'],
            ]);
            if ($pendingTransactions->count()) {
                throw new Exception("Transaction is being processed");
            }
            $kabanchiks = Kabanchik::where([['user_id', '=', $user->id], ['value', '>', 1e-18]]);
            if ($kabanchiks->count()) {
                throw new Exception("You cannot buy more than one egg or kabanchik at once");
            }
        }

        try {
            $transaction = $this->walletService->buyForOglc($user, $shopItem->price_oglc);
        } catch (InsufficientBNBException $e) {
            throw $e;
            // try {
            //     $transaction = $this->walletService->exchange(
            //         $user, 'bnb', 'oglc',
            //         $this->walletService->convert('oglc', 'bnb', $shopItem->price_bnb)
            //     );
            // }
        }
        if (!$transaction) {
            throw new Exception("Unable to create transaction. Try again later");
        }
        $transaction->update(['comment' => 'shopItem:'.$shopItem->id]);

        if ($shopItem->type == 'egg') {
            $kabanchik = $this->kabanchikGameService->addPurchasedEgg($transaction->user, $shopItem);
            $transaction->update([
                'comment' => $transaction->comment . ',kabanchik:'.$kabanchik->id
            ]);
            $this->websocketService->sendMessage($kabanchik->user_id, [
                'event' => 'buy_egg',
                'kabanchik_id' => $kabanchik->id,
                'transaction_id' => $transaction->id,
                'amount' => $transaction->amount
            ]);
        }

        return $transaction;
    }

    /**
     * Try to buy an item for OGLC. In case there's not enough OGLC, try to exchange BNB to OGLC and buy later
     * @param  User     $user     User that wants to buy an item
     * @param  ShopItem $shopItem Item to buy
     * @return Transaction        Buy for OGLC transaction or an exchange transaction
     * @throws InsufficientOGLCException Insufficient OGLC balance
     * @throws InsufficientBNBException Insufficient BNB balance
     */
    function buyForOglc(User $user, ShopItem $shopItem): Transaction
    {
        if ($shopItem->type == 'egg') {
            $pendingTransactions = Transaction::where([
                ['user_id', '=', $user->id],
                ['type', '=', 'buy'],
                ['status', '=', 'pending'],
            ]);
            if ($pendingTransactions->count()) {
                throw new Exception("Transaction is being processed");
            }
            $kabanchiks = Kabanchik::where([['user_id', '=', $user->id], ['value', '>', 1e-18]]);
            if ($kabanchiks->count()) {
                throw new Exception("You cannot buy more than one egg or kabanchik at once");
            }
        }

        try {
            $transaction = $this->walletService->buyForOglc($user, $shopItem->price_oglc);
        } catch (InsufficientOGLCException $e) {
            throw $e;
            // try {
            //     $transaction = $this->walletService->exchange(
            //         $user, 'bnb', 'oglc',
            //         $this->walletService->convert('oglc', 'bnb', $shopItem->price_bnb)
            //     );
            // }
        }
        if (!$transaction) {
            throw new Exception("Unable to create transaction. Try again later");
        }
        $transaction->update(['comment' => 'shopItem:'.$shopItem->id]);

        if ($shopItem->type == 'egg') {
            $kabanchik = $this->kabanchikGameService->addPurchasedEgg($transaction->user, $shopItem);
            $transaction->update([
                'comment' => $transaction->comment . ',kabanchik:'.$kabanchik->id
            ]);
            $this->websocketService->sendMessage($kabanchik->user_id, [
                'event' => 'buy_egg',
                'kabanchik_id' => $kabanchik->id,
                'transaction_id' => $transaction->id,
                'amount' => $transaction->amount,
                'currency' => $transaction->currency
            ]);
        }

        return $transaction;
    }

    /**
     * Should be called when a buy transaction is marked as successful/failed
     * @param Transaction $transaction Buy for OGLC transaction
     */
    function finishPurchase(Transaction $transaction): bool
    {
        if ($transaction->status != 'success') {
            return false;
        }
        $transactionDataArray = explode(',', $transaction->comment);
        $transactionData = [];
        foreach ($transactionDataArray as &$ent) {
            $data = explode(':', $ent);
            if (count($data) == 2) {
                list($key, $value) = $data;
                $transactionData[$key] = $value;
            }
        }
        if (!isset($transactionData['shopItem']) || !isset($transactionData['kabanchik'])) {
            return false;
        }
        $shopItem = ShopItem::find($transactionData['shopItem']);
        $kabanchik = Kabanchik::find($transactionData['kabanchik']);
        if (!$shopItem) {
            return false;
        }

        if ($shopItem->type == 'egg') {
            bcscale(18);
            // TODO calculate kabanchik price?
            $kabanchik->update([
                'value' => $shopItem->data['value'] ?? bcdiv($transaction->amount, '2'),
                'hidden_value' => $shopItem->data['hidden_value'] ?? bcdiv($transaction->amount, '2'),
                'is_locked' => 0
            ]);
            $this->websocketService->sendMessage($kabanchik->user_id, [
                'event' => 'buy_egg',
                'kabanchik_id' => $kabanchik->id,
                'transaction_id' => $transaction->id,
                'amount' => $transaction->amount
            ]);
            return true;
        }
        return false;
    }

    function cancelPurchase(Transaction $transaction): bool
    {
        if ($transaction->status != 'fail') {
            return false;
        }
        $transactionData = \transactionDataToArray($transaction->comment);
        if (!isset($transactionData['shopItem']) || !isset($transactionData['kabanchik'])) {
            return false;
        }
        $shopItem = ShopItem::find($transactionData['shopItem']);
        $kabanchik = Kabanchik::find($transactionData['kabanchik']);
        if (!$shopItem) {
            return false;
        }
        if ($kabanchik) {
            $kabanchik->delete();
        }
        return true;
    }
}
