<?php
namespace App\Services;
use App\Models\Game;
use App\Models\Kabanchik;
use App\Models\User;
use App\Models\GameEntry;
use App\Models\Transaction;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Carbon\CarbonImmutable;
use \Exception;
use App\Services\KabanchikGameService;
use App\Http\Resources\KabanchikResource;
use App\Http\Resources\EndGameNotificationResource;
use App\Services\WebsocketService;

class GameService
{
    const MIN_BET = 0.010;
    const WIN_LIMIT = KabanchikGameService::LEVEL_COST*6;

    public function __construct(KabanchikGameService $kabanchikGameService)
    {
        $this->kabanchikGameService = $kabanchikGameService;
    }

    public function getLastGame(): Game
    {
        return Game::orderBy('id', 'desc')->first();
    }

    public function getCurrentGame(): ?Game
    {
        return Game::where([['is_ended', '=', 0], ['ends_at', '>', CarbonImmutable::now()]])
                   ->first();
    }

    public function getRecentlyEndedGame(): ?Game
    {
        return Game::where([['is_ended', '=', 0], ['ends_at', '<', CarbonImmutable::now()]])
                   ->first();
    }

    public function createNewGame(): Game
    {
        $now = CarbonImmutable::now();
        $nextHour = $now->addSeconds(env('GAME_INTETVAL', 600));
        $nextGameEnds = CarbonImmutable::create($nextHour->year, $nextHour->month, $nextHour->day,
                                                $nextHour->hour, $nextHour->minute, 0);
        $canActBefore = $nextGameEnds->subSeconds(env('GAME_GENESIS_TIME', 60));
        return Game::create([
            'can_act_before' => $canActBefore,
            'ends_at' => $nextGameEnds,
            'is_ended' => 0
        ]);
    }

    private function calculateTotalGreed(iterable $entries, int $offset): float
    {
        $N = count($entries);
        $totalGreed = 0;
        for ($i=$offset; $i<$N; $i++) {
            $totalGreed += $entries[$i]->greed;
        }
        return $totalGreed;
    }

    private function calculateTotalExpectations(iterable $entries, int $offset): float
    {
        $N = count($entries);
        $totalExpectations = 0;
        for ($i=$offset; $i<$N; $i++) {
            $totalExpectations += $entries[$i]->expects;
        }
        return $totalExpectations;
    }

    private function logWindow($first, $last, $current)
    {
        if ($last == $first) return 1;
        return 0.03 + 0.97*log(1 + ($current-$first)/($last-$first), 2);
    }

    private function inverseLogWindow($first, $last, $current)
    {
        if ($last == $first) return 1;
        return 1 - 0.97*log(1 + ($current-$first)/($last-$first), 2);
    }

    private function calculateTotalExpectations_logWindow(iterable $entries, int $offset): float
    {
        $N = count($entries);
        $length = $N - $offset - 1;
        $totalExpectations = 0.;
        for ($i=$offset; $i<$N; $i++) {
            $multiplier = $this->inverseLogWindow($offset, $N-1, $i);
            $totalExpectations += max(self::MIN_BET, $multiplier * $entries[$i]->expects);
        }
        return $totalExpectations;
    }

    private function calculateTotalBids_logWindow(iterable $entries, int $length): float
    {
        $totalBids = 0.;
        for ($i=0; $i<$length; $i++) {
            $multiplier = $this->inverseLogWindow(0, $length-1, $i);
            $totalBids += max(
                min($entries[$i]->deposit, self::MIN_BET),
                $multiplier * $entries[$i]->deposit
            );
        }
        return $totalBids;
    }

    private function bisectCalculateSum(iterable $sortedGameEntries, int $firstIndex, int $lastIndex, bool $useExpectationsInsteadOfDeposit=false): float
    {
        $sum = 0.0;
        $length = $lastIndex - $firstIndex;
        if ($length < 0) return 0.;
        for ($i=$firstIndex; $i <= $lastIndex; $i++) {
            $multiplier = $this->inverseLogWindow($firstIndex, $lastIndex, $i);
            if ($useExpectationsInsteadOfDeposit)
                $sum += max(self::MIN_BET, $multiplier * $sortedGameEntries[$i]->expects);
            else
                $sum += max(
                    min($sortedGameEntries[$i]->deposit, self::MIN_BET),
                    $multiplier * $sortedGameEntries[$i]->deposit
                );
        }
        return $sum;
    }

    /**
     * Returns index of the first winner
     * $sortedGameEntries[0] .. $sortedGameEntries[index-1] are losers
     * $sortedGameEntries[index] .. $sortedGameEntries[length-1] are winners
     * The sum of deposits before index should be greater or equal to the
     * sum of expectations from index onwards
     * @param  iterable $sortedGameEntries Game entries sorted by greediness, high to low
     * @return int                         index of the first winner
     */
    public function bisect(iterable $sortedGameEntries): int
    {
        $pointer = -1;
        $length = count($sortedGameEntries);
        if ($length < 2) return -1;
        if ($length == 2) return 1;
        $last = $length - 1;
        $lowerLimit = 0;
        $upperLimit = $last;
        $previousPointerLeftLTRight = -1;
        $previousPointerLeftGTRight = -1;
        $dir = true;
        $iter = 0;
        while (true) {
            $pointer = (int)($lowerLimit + ($upperLimit - $lowerLimit)/2);
            if ($pointer == $previousPointerLeftLTRight) {
                $pointer++;
            }
            if ($pointer == $previousPointerLeftGTRight) {
                break;
            }
            $sumBefore = $this->bisectCalculateSum($sortedGameEntries, 0, $pointer-1, false);
            $sumAfter = $this->bisectCalculateSum($sortedGameEntries, $pointer, $last, true);
            //print("Step ".($iter++).": ".$pointer." ".$sumBefore." <> ".$sumAfter."\n");
            if ($sumBefore > $sumAfter) {
                $upperLimit = $pointer;
                $previousPointerLeftGTRight = $pointer;
            } else if ($sumBefore < $sumAfter) {
                $lowerLimit = $pointer;
                $previousPointerLeftLTRight = $pointer;
            } else {
                break;
            }
        }
        //print("pointer -> $pointer\n");
        return max(1, (($pointer <= $length-1)? $pointer : $length-2));
    }

    public function randomMultiplier($minAngle, $maxAngle)
    {
        $randomAngle = random_int($minAngle*1000, $maxAngle*1000)/1000;
        $mult = 1 / cos($randomAngle/180*M_PI);
        return $mult;
    }

    public function process(?Game $game=null)
    {
        if (!$game)
            $game = $this->getRecentlyEndedGame();
        if (!$game) {
            if (!$this->getCurrentGame()) {
                $this->createNewGame();
            }
            return;
        }
        if (CarbonImmutable::now()->lessThan($game->ends_at)) {
            return;
        }

        // $this->processGame($game);
        $this->kabanchikGameService->playGame($game);

        $commonData = (new EndGameNotificationResource(['game' => $game]))->toArray("");
        $gameUserIds = $game->gameEntries()->select(DB::raw('distinct user_id'))->pluck('user_id');
        // $webSocketService->sendMessage(
        //     WebsocketService::ALL_USERS,
        //
        // );
        // Send message for all users
        bcscale(18);
        $webSocketService = app(WebsocketService::class);
        foreach ($gameUserIds as &$userId) {
          $user = User::find($userId);
          $kabanchiks = Kabanchik::where([['user_id', '=', $userId],
                                  ['is_locked', '=', 0],
                                  ['value', '>', 1e-18]])
                         ->get();
          $kabanchikStats = [];
          $totalRoundOutcome = "0";
          foreach ($kabanchiks as &$kabanchik) {
              $gameEntry = GameEntry::where([['kabanchik_id', '=', $kabanchik->id],
                                             ['game_id', '=', $game->id]])
                                    ->first();
              if (!$gameEntry) {
                continue;
              }
              $outcome = bcsub($gameEntry->result, $gameEntry->deposit);
              $kabanchikStats[] = [
                  'kabanchik' => (new KabanchikResource($kabanchik))->toArray(""),
                  'round_outcome' => $outcome,
              ];
              $totalRoundOutcome = bcadd($totalRoundOutcome, $outcome);
          }
          $payload = array_merge(
              $commonData,
              [
                  'stats' => $kabanchikStats,
                  'total_round_outcome' => $totalRoundOutcome
              ]
          );
          $webSocketService->sendMessage(
              $userId,
              $payload
          );
        }

        $this->createNewGame();
    }

    public function getGameInfo(Game $game)
    {
        if (!$game->cached_at || !Carbon::now()->subSeconds(5)->lessThan($game->cached_at)) {
            // $participants = User::where([['balance', '>=', 1e-8], ['multiplier', '>', 1]])
            //                     ->select('balance', 'multiplier')
            //                     ->get()->toArray("");
            $kabanchiks = Kabanchik::where([['value', '>=', KabanchikGameService::MIN_BET],
                                    ['is_locked', '=', 0],
                                    ['risk', '>', 0]])
                           ->select('value', 'risk');
            $nBids = 0;
            $pool = 0;
            foreach ($kabanchiks as &$row) {
                $nBids++;
                // $pool += $row['balance']; //min($row['balance'], $row['balance']*($row['multiplier']-1));
                $pool += min($row['balance'], $row['balance']*($row['risk']));
            }
            $game->update([
                'total_bids' => $nBids,
                'total_pool' => $pool,
                'cached_at' => CarbonImmutable::now()
            ]);
        }
        // if ($game->total_bids < 10) {
        //     return [
        //         'totalBids' => "<10",
        //         'totalPool' => -1,
        //         'meanBet' => $game->total_bids ? $game->total_pool/$game->total_bids : 0
        //     ];
        // }
        return [
            'totalBids' => $game->total_bids,
            'totalPool' => $game->total_pool,
            'meanBet' => $game->total_bids ? $game->total_pool/$game->total_bids : 0
        ];
    }

    public function updateUserMultiplier(User $user, float $multiplier): Game
    {
        if ($multiplier < 1) {
            throw new Exception("Multiplier should be greater than or equal to 1.0");
        }
        $currentGame = $this->getCurrentGame();
        if (Carbon::now()->greaterThan($currentGame->can_act_before)) {
            throw new Exception("Cannot join this round because it is being processed already");
        }
        $user->update(['multiplier' => $multiplier]);
        $kabanchik = $this->kabanchikGameService->getKabanchikForUser($user);
        if ($kabanchik) {
            $kabanchik->update(['multiplier' => $multiplier]);
        }
        return $currentGame;
    }

    public function updateKabanchikRisk(Kabanchik $kabanchik, float $risk): Game
    {
        if ($risk < 0 || $risk > 1) {
            throw new Exception("Multiplier should be between 0.0 .. 1.0");
        }
        $currentGame = $this->getCurrentGame();
        if (Carbon::now()->greaterThan($currentGame->can_act_before)) {
            throw new Exception("Cannot join this round because it is being processed already");
        }
        $kabanchik->update(['risk' => $risk]);
        return $currentGame;
    }

    public function joinGame(Game $game, User $user, float $risk, float $deposit): GameEntry
    {
        if ($deposit < 0) {
            throw new Exception("Deposit should be a positive number");
        }
        if (Carbon::now()->greaterThan($game->can_act_before)) {
            throw new Exception("Cannot join this round because it ends in 1 minute or less");
        }
        if ($user->balance < $deposit) {
          throw new Exception("Insufficient balance");
        }
        if ($game->gameEntries->where('user_id', '=', $user->id)->count() > 0) {
            throw new Exception("Already joined");
        }

        $gameEntry = GameEntry::create([
            'game_id' => $game->id,
            'user_id' => $user->id,
            'deposit' => $deposit,
            'expects' => 0.0,
            'risk' => $risk,
            'result' => $deposit,
        ]);
        $transaction = Transaction::create([
          'user_id' => $user->id,
          'game_id' => $game->id,
          'game_entry_id' => $gameEntry->id,
          'type' => 'bet',
          'amount' => -$deposit
        ]);
        $user->balance -= $deposit;
        $user->save();

        return $gameEntry;
    }

    public function shouldProcessUser(User $user)
    {}

    public function isGameLocked(Game $game): bool
    {
        return Carbon::now()->greaterThan($game->can_act_before);
    }

    public function leaveGame(Game $game, User $user): bool
    {
        if (Carbon::now()->greaterThan($game->can_act_before)) {
            throw new Exception("Cannot leave this round because it ends in 1 minute or less");
        }
        //
    }

    public function getReferredUsersCountFor(User $user): int
    {
        $referredUsers = User::where('ref_user_id', '=', $user->id);
        $referredUsersCount = 0;
        $referredUsers->each(function ($refUser) use (&$referredUsersCount) {
            if (Kabanchik::where('user_id', '=', $refUser->id)->count() > 0) {
                $referredUsersCount++;
            }
        });
        return $referredUsersCount;
    }
}
