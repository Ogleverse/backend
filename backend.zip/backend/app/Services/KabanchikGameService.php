<?php
namespace App\Services;

use App\Models\User;
use App\Models\Kabanchik;
use App\Models\KabanchikSkin;
use App\Models\Transaction;
use App\Models\Game;
use App\Models\GameEntry;
use App\Models\ShopItem;
use App\Services\TransactionService;
use App\Services\WebsocketService;
use App\Services\WalletService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Exception;

class KabanchikGameService
{
    const MIN_BET = 0.00000001;
    const OOGLE_COST = 10.00;
    const LEVEL_COST = 25;
    const RISK_HIGH = 0.5;
    const RISK_LOW = 0.2;
    const MIN_ZONE_BONUS = -0.05;
    const MAX_ZONE_BONUS = 0.05;
    const MAX_RANDOM_ANGLE = 0.8;
    const MIN_RANDOM_ANGLE = 0.35;
    const MAX_RANDOM_RISK = 0.9;
    const MIN_RANDOM_RISK = 0.8;
    const EMIT_TOP_GREED = 4;
    const EMIT_SECOND_TOP_GREED = 2;

    public function __construct(TransactionService $transactionService, WebsocketService $websocketService, WalletService $walletService)
    {
        $this->transactionService = $transactionService;
        $this->websocketService = $websocketService;
        $this->walletService = $walletService;
    }

    public function getTotalPool(Game $game)
    {
        $pool = 0.0;
        foreach ($game->gameEntries as &$entry) {
            $pool += $entry->kabanchik->value;
        }
        return $pool;
    }


    public function getKabanchikGreed(GameEntry $gameEntry)
    {
        $kabanchik = $gameEntry->kabanchik;
        $game = $gameEntry->game;

        $value = $gameEntry->type == 'value'
            ? $kabanchik->value
            : $kabanchik->hidden_value;

        $risk = $gameEntry->risk;

        $bet = $value * $risk;

        $greed = $risk * $bet;
        return $greed;
    }

    public function randomRisk($minRisk, $maxRisk)
    {
        return random_int((int)($minRisk*1e6), (int)($maxRisk*1e6))/1e6;
    }

    public function createNewGame(): Game
    {
        $now = CarbonImmutable::now();
        $nextHour = $now->addSeconds(env('GAME_INTETVAL', 600));
        $nextGameEnds = CarbonImmutable::create($nextHour->year, $nextHour->month, $nextHour->day,
                                                $nextHour->hour, $nextHour->minute, 0);
        $canActBefore = $nextGameEnds->subSeconds(env('GAME_GENESIS_TIME', 60));
        return Game::create([
            'can_act_before' => $canActBefore,
            'ends_at' => $nextGameEnds,
            'is_ended' => 0
        ]);
    }

    public function prepareKabanchikForGame(Kabanchik $kabanchik, Game $game): iterable
    {
        if (!$kabanchik) return [];
        $gameEntries = [];
        if ($kabanchik->value > self::MIN_BET && $kabanchik->risk > 0) {
            $risk = $kabanchik->risk;
            $bet = $risk*$kabanchik->value;
            Log::debug("before game: {\"game_id\":{$game->id}, \"kabanchik_id\": {$kabanchik->id}, \"value\": {$kabanchik->value}}");
            $gameEntry = GameEntry::create([
                'user_id' => $kabanchik->user_id,
                'game_id' => $game->id,
                'kabanchik_id' => $kabanchik->id,
                'type' => 'value',
                'deposit' => $bet,
                'result' => $bet,
                'expects' => $kabanchik->value * 2*$kabanchik->risk,
                'risk' => $kabanchik->risk
            ]);
            $transaction = Transaction::create([
                'user_id' => $kabanchik->user_id,
                'game_entry_id' => $gameEntry->id,
                'game_id' => $gameEntry->game_id,
                'kabanchik_id' => $kabanchik->id,
                'type' => 'bet',
                'amount' => $bet,
            ]);
            // $kabanchik->value -= $bet;
            $gameEntries []= $gameEntry;
        }
        if ($kabanchik->hidden_value > self::MIN_BET) {
            $risk = $this->randomRisk(self::MIN_RANDOM_RISK, self::MAX_RANDOM_RISK);
            // $bet = $risk*$kabanchik->hidden_value;
            $bet = min($kabanchik->hidden_value, max($kabanchik->hidden_value/2, self::MIN_BET));
            $expects = (1+$risk)*max(self::MIN_BET*100, $kabanchik->hidden_value/2);
            $gameEntry = GameEntry::create([
                'user_id' => $kabanchik->user_id,
                'game_id' => $game->id,
                'kabanchik_id' => $kabanchik->id,
                'type' => 'hidden_value',
                'deposit' => $bet,
                'expects' => $expects,
                'result' => $bet,
                'risk' => $risk
            ]);
            $transaction = Transaction::create([
                'user_id' => $kabanchik->user_id,
                'game_entry_id' => $gameEntry->id,
                'game_id' => $gameEntry->game_id,
                'kabanchik_id' => $kabanchik->id,
                'type' => 'kabanchik_bet',
                'amount' => $bet,
            ]);
            // $kabanchik->hidden_value -= $bet;
            $gameEntries []= $gameEntry;
        }
        $kabanchik->save();
        return $gameEntries;
    }

    public function getSortedBaskets(Game $game)
    {
        $greedBaskets = [];
        foreach ($game->gameEntries as &$gameEntry) {
            $kabanchik = $gameEntry->kabanchik;
            $greed = $this->getKabanchikGreed($gameEntry);
            // echo "Greed: ";
            // var_dump($greed);
            $greedFixed = sprintf("%.8f", $greed);
            $greedBaskets[$greedFixed] = $greedBaskets[$greedFixed] ?? [];
            $greedBaskets[$greedFixed] []= $gameEntry;
            print("gameEntry {$gameEntry->id} greed={$greedFixed}\n");
        }
        $sorter = function ($a, $b) {
            $floatA = (float)$a;
            $floatB = (float)$b;
            if ($floatA > $floatB) {
                return -1;
            } else if ($floatA < $floatB) {
                return 1;
            } else {
                return 0;
            }
        };
        $greeds = array_keys($greedBaskets);
        usort($greeds, $sorter);
        $sortedGreedBaskets = [];
        foreach ($greeds as &$greed) {
            $sortedGreedBaskets []= $greedBaskets[$greed];
        }
        $topGreedyPlayerIndex = -1;
        for ($i=0; $i<count($sortedGreedBaskets); $i++) {
            $basket = &$sortedGreedBaskets[$i];
            foreach ($basket as &$entry) {
                if ($entry->type == 'value' && $entry->kabanchik->value < ($this->getTotalPool($game) * 0.13) ) { //&& !$entry->kabanchik->top_greed_last_round
                    $topGreedyPlayerIndex = $i+1;
                    $i = count($sortedGreedBaskets);
                    break;
                }
            }
        }
        Kabanchik::where('id', '>', 0)->update(['top_greed_last_round' => false]);
        print("\033[1;31mTop greedy player index $topGreedyPlayerIndex\033[m\n");
        $topGreedBasket = array_splice($sortedGreedBaskets, $topGreedyPlayerIndex, 1);
        if (count($topGreedBasket)) {
            $topGreedBasket = $topGreedBasket[0];
            foreach ($topGreedBasket as &$entry) {
                //$entry->kabanchik->update(['top_greed_last_round' => true]);
                $entry->kabanchik->experience += 50;
            }
            $sortedGreedBaskets []= $topGreedBasket;
        }
        return $sortedGreedBaskets;
    }

    private function sumExpectations(iterable $baskets, int $firstIndex, int $lastIndex) {
        $expectations = 0;
        for ($i=$firstIndex; $i <= $lastIndex; $i++) {
            $basket = $baskets[$i];
            foreach ($basket as &$gameEntry) {
                $expectations += $gameEntry->expects;
            }
        }
        return $expectations;
    }

    private function hardExpectationFor (GameEntry $gameEntry, int $firstIndex, int $lastIndex, int $basketIndex) {
        return min($gameEntry->deposit, $gameEntry->expects);
    }

    private function sumExpectationsHard(iterable $baskets, int $firstIndex, int $lastIndex) {
        $expectations = 0;
        for ($i=$firstIndex; $i <= $lastIndex; $i++) {
            $basket = $baskets[$i];
            foreach ($basket as &$gameEntry) {
                try {
                    $expectations += $this->hardExpectationFor($gameEntry, $firstIndex, $lastIndex, $i);
                } catch (Exception $e) {
                    dd($gameEntry);
                }
            }
        }
        return $expectations;
    }

    private function sumBets(iterable $baskets, int $firstIndex, int $lastIndex) {
        $bets = 0;
        for ($i=$firstIndex; $i <= $lastIndex; $i++) {
            $basket = $baskets[$i];
            foreach ($basket as &$gameEntry) {
                $bets += $gameEntry->deposit;
            }
        }
        return $bets;
    }

    public function getFirstWinningBasketIndex(iterable $sortedGreedBaskets, int $firstIndex=0, int $lastIndex=0)
    {
        $len = count($sortedGreedBaskets);
        if (!$lastIndex) {
            $lastIndex = $len-1;
        }
        if ($len < 2) {
            return -1;
        } else if ($len == 2) {
            return 1;
        }
        $last = $len - 1;
        $lowerLimit = 0;
        $upperLimit = $last;
        $previousPointerLeftLTRight = -1;
        $previousPointerLeftGTRight = -1;
        $dir = true;
        $iter = 0;
        while (true) {
            $pointer = (int)($lowerLimit + ($upperLimit - $lowerLimit)/2);
            if ($pointer == $previousPointerLeftLTRight) {
                echo "p($pointer) == prevL<R\n";
                $pointer++;
            }
            if ($pointer == $previousPointerLeftGTRight) {
                echo "p($pointer) == prevL>R, break\n";
                break;
            }
            $sumLoses = $this->sumBets($sortedGreedBaskets, 0, $pointer-1);
            // var_dump($pointer);
            $sumWinnings = $this->sumExpectationsHard($sortedGreedBaskets, $pointer, $last);
            print("Step ".($iter++).": ".$pointer." ".$sumLoses." <> ".$sumWinnings."\n");
            if ($sumLoses > $sumWinnings) {
                $upperLimit = $pointer;
                $previousPointerLeftGTRight = $pointer;
                print("loses > winnings, up=$pointer, prevL>R=$pointer\n");
            } else if ($sumLoses < $sumWinnings) {
                $lowerLimit = $pointer;
                $previousPointerLeftLTRight = $pointer;
                print("loses < winnings, low=$pointer, prevL<R=$pointer\n");
            } else {
                break;
            }
        }
        print("pointer -> $pointer\n");
        print("pointer -> ".max(1, (($pointer <= $len-1)? $pointer : $len-2))."\n");
        $sumLoses = $this->sumBets($sortedGreedBaskets, 0, $pointer-1);
        $sumWinnings = $this->sumExpectationsHard($sortedGreedBaskets, $pointer, $last);
        if ($sumWinnings > $sumLoses) {
            dd('w, l, l-w', $sumWinnings, $sumLoses, $sumLoses-$sumWinnings);
        }
        // var_dump(['w, l, l-w', $sumWinnings, $sumLoses, $sumLoses-$sumWinnings]);
        return max(1, (($pointer <= $len-1)? $pointer : $len-2));
    }

    public function processKabanchikAfterGame(GameEntry $gameEntry)
    {
        $kabanchik = $gameEntry->kabanchik;
        $kabanchik->refresh();
        $risk = $kabanchik->risk;
        if ($gameEntry->type == 'value') {
            $newValue = $kabanchik->value + $gameEntry->result - $gameEntry->deposit;
            $kabanchik->value = $newValue;
            $kabanchik->update(['value' => $newValue]);
            if ($gameEntry->result > $gameEntry->deposit) {
                if ($risk > self::RISK_HIGH && $kabanchik->zone_bonus < self::MAX_ZONE_BONUS) {
                    $kabanchik->zone_bonus += 0.001;
                } else if ($risk > 0 && $risk < self::RISK_LOW && $kabanchik->zone_bonus > self::MIN_ZONE_BONUS) {
                    $kabanchik->zone_bonus -= 0.001;
                }
            }
            if (($risk >= self::RISK_LOW && $risk <= self::RISK_HIGH) || $risk == 0) {
                if ($kabanchik->zone_bonus > 0) {
                    $kabanchik->zone_bonus -= 0.001;
                } else if ($kabanchik->zone_bonus < 0) {
                    $kabanchik->zone_bonus += 0.001;
                }
            }
            if ($gameEntry->result > 0) {
                Transaction::create([
                    'user_id' => $kabanchik->user_id,
                    'game_id' => $gameEntry->game_id,
                    'kabanchik_id' => $kabanchik->id,
                    'game_entry_id' => $gameEntry->id,
                    'type' => 'win',
                    'amount' => $gameEntry->result,
                ]);
                $kabanchik->experience += 30;
            } else {
                $kabanchik->experience += 5;
            }

            Log::debug("after game: {\"game_id\":{$gameEntry->game_id}, \"kabanchik_id\": {$kabanchik->id}, \"value\": {$kabanchik->value}, \"in\": {$gameEntry->deposit}, \"out\": {$gameEntry->result}}");
        } else if ($gameEntry->type == 'hidden_value') {
            $newHiddenValue = $kabanchik->hidden_value + $gameEntry->result - $gameEntry->deposit;
            $kabanchik->hidden_value = $newHiddenValue;
            $kabanchik->update(['hidden_value' => $newHiddenValue]);
            if ($gameEntry->result > 0) {
                Transaction::create([
                    'user_id' => $kabanchik->user_id,
                    'game_id' => $gameEntry->game_id,
                    'kabanchik_id' => $kabanchik->id,
                    'game_entry_id' => $gameEntry->id,
                    'type' => 'kabanchik_win',
                    'amount' => $gameEntry->result,
                ]);
            }
            if ($kabanchik->level == 0) {
                $kabanchik->experience += 1;
            }
        }
        $this->updateKabanchik($kabanchik, $kabanchik->value, $kabanchik->hidden_value, 0);

        // $kabanchik->save();
        $gameEntry->save();
    }

    private function clipDecimal(float $value, int $decimals=8): iterable
    {
        $mult = 10**$decimals;
        $value *= $mult;
        $whole = floor($value);
        $fraction = $value - $whole;
        return [$whole/$mult, $fraction/$mult];
    }

    public function distributeValues(iterable $baskets, int $firstWinnerIndex)
    {
        if ($firstWinnerIndex < 1) return;
        $totalLost = 0.0;
        $totalBets = 0.0;
        $totalWins = 0.0;
        $totalExpectationsHard = $this->sumExpectationsHard($baskets, $firstWinnerIndex, count($baskets)-1);
        $totalExpectations = $this->sumExpectations($baskets, $firstWinnerIndex, count($baskets)-1);
        $totalLost2 = $this->sumBets($baskets, 0, $firstWinnerIndex-1);
        // Move losers' value to pool
        for ($i=0; $i<$firstWinnerIndex; $i++) {
            $basket = $baskets[$i];
            foreach ($basket as &$gameEntry) {
                $bet = $gameEntry->deposit;
                $resultBefore = $gameEntry->result;
                $totalLost += $gameEntry->result;
                $gameEntry->result = 0;
                $gameEntry->save();
                print("ge: $bet, $resultBefore -> 0\n");
            }
        }
        $overflowWinnings = $totalLost - $totalExpectationsHard;

        $totalErr = 0.0;
        $totalWins = 0.0;
        $totalERH = 0.0;
        $nBaskets = count($baskets);
        function countUsersInBasket ($basket) {
            $count = 0;
            foreach ($basket as &$gameEntry) {
                if ($gameEntry->type == 'value') $count++;
            }
            return $count;
        }
        for ($i=$firstWinnerIndex; $i<count($baskets); $i++) {
            $basket = $baskets[$i];
            $nUsersInBasket = countUsersInBasket($basket);
            foreach ($basket as &$gameEntry) {
                $risk = $gameEntry->risk;
                $expectsHard = $this->hardExpectationFor($gameEntry, $firstWinnerIndex, $nBaskets-1, $i);
                $expectationRatioHard = $expectsHard/($totalExpectationsHard + 1e-8);
                $totalERH += $expectationRatioHard;
                $expectationRatio = $gameEntry->expects/($totalExpectations + 1e-8);
                $sum = $totalLost * $expectationRatioHard;
                // $sum = $totalExpectationsHard * $expectationRatioHard
                //         + $overflowWinnings * $expectationRatioHard;
                [$win, $err] = $this->clipDecimal($sum);
                $totalWins += $win;
                $bet = $gameEntry->deposit;
                $resultBefore = $gameEntry->result;

                // emission
                if ($gameEntry->deposit > 0) {
                    if ($i == $nBaskets-1) {
                        if ($nUsersInBasket > 0 && $gameEntry->type == 'value') {
                            $gameEntry->result += self::EMIT_TOP_GREED/$nUsersInBasket;
                        } else {
                            for ($k = $nBaskets-2; $k>=0; $k--) {
                                $nUsers = countUsersInBasket($baskets[$k]);
                                if ($nUsers > 0) {
                                    foreach ($baskets[$k] as &$entry) {
                                        if ($entry->type == 'value')
                                            $entry->result += self::EMIT_TOP_GREED/$nUsers;
                                    }
                                    break;
                                }
                            }
                        }
                    } else if ($i == $firstWinnerIndex) {
                        if ($nUsersInBasket > 0) {
                            $gameEntry->result += self::EMIT_SECOND_TOP_GREED/$nUsersInBasket;
                        } else {
                            for ($k = $firstWinnerIndex+1; $k < $nBaskets; $k++) {
                                $nUsers = countUsersInBasket($baskets[$k]);
                                if ($nUsers > 0) {
                                    foreach ($baskets[$k] as &$entry) {
                                        if ($entry->type == 'value')
                                            $entry->result += self::EMIT_SECOND_TOP_GREED/$nUsers;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
                // if ( ($i == count($baskets)-1 || $i == $firstWinnerIndex) && $gameEntry->deposit > 0 ) {
                //     $gameEntry->result += self::EMIT_PER_DAY/144/count($basket);
                // }
                $gameEntry->result += $win;
                $gameEntry->save();
                $resultAfter = $gameEntry->result;
                print("ge: $bet, $resultBefore -> $resultAfter\n");
                $totalErr += $err;
            }
        }

        print("\033[1;33mOverflow: $totalERH L=$totalLost, W=$totalWins, E=$totalExpectationsHard O=".$overflowWinnings."\033[m\n");
    }

    public function saveRoundingErrors(Game $game)
    {
        $totalRoundingError = DB::table('game_entries')
                                ->where('game_id', '=', $game->id)
                                ->sum(DB::raw('deposit - result'));
        Transaction::create([
            'user_id' => null,
            'game_id' => $game->id,
            'game_entry_id' => null,
            'type' => 'rounding_error',
            'amount' => $totalRoundingError
        ]);
    }

    public function getKabanchiksForGame(Game $game)
    {
        $kabanchiks = Kabanchik::where([
            ['is_locked', '=', 0],
            ['value', '>=', self::MIN_BET],
            ['risk', '>', 0],
        ])->orWhere('hidden_value', '>=', 1e-3)->get();
        return $kabanchiks;
    }

    public function decreaseIdleKabanchiksZoneBonus()
    {
        Kabanchik::where([['is_locked', '=', 0],
                      ['value', '>=', self::MIN_BET],
                      ['risk', '=', 0]])
             ->each(function ($kabanchik) {
                if ($kabanchik->zone_bonus > 0) {
                    $kabanchik->zone_bonus -= 0.001;
                } else if ($kabanchik->zone_bonus < 0) {
                    $kabanchik->zone_bonus += 0.001;
                }
                $kabanchik->save();
             });
    }

    public function playGame(Game $game)
    {
        if ($game->is_ended) return;
        $kabanchiks = $this->getKabanchiksForGame($game);
        // DB::beginTransaction();
        foreach ($kabanchiks as &$kabanchik) {
            $gameEntries = $this->prepareKabanchikForGame($kabanchik, $game);
        }
        $game->load('gameEntries');
        $baskets = $this->getSortedBaskets($game);

        $firstWinnerIndex = $this->getFirstWinningBasketIndex($baskets);
        echo "count: ";
        var_dump(count($baskets));
        echo "1st win: ";
        var_dump($firstWinnerIndex);
        // var_dump(array_keys($baskets));
        $this->distributeValues($baskets, $firstWinnerIndex);
        foreach ($baskets as &$basket) {
            foreach ($basket as &$gameEntry) {
                $this->processKabanchikAfterGame($gameEntry);
            }
        }
        $this->saveRoundingErrors($game);
        $game->update(['is_ended' => 1]);
        $this->decreaseIdleKabanchiksZoneBonus();
        // DB::commit();
    }

    public function getRandomSkin($cat)
    {
        if ($cat == 'c') {
            $index = random_int(1, 56);
        } else if ($cat == 'p') {
            $index = random_int(1, 21);
        }
        return KabanchikSkin::where('name', $cat.$index)->first();
    }

    private function rubToCost(float $rub)
    {
        return $rub / 35886.34;
    }

    public function addPurchasedEgg(User $user, ShopItem $shopItem)
    {
        $shopItemData = $shopItem->data;
        $kabanchik = Kabanchik::make([
            'user_id' => $user->id,
            'risk' => 0,
            'level' => 0,
            'type' => 'egg',
            'is_locked' => 1,
            'collection' => $shopItemData['collection'] ?? 'basic',
            'rarity' => $shopItemData['rarity'] ?? 'common',
            'type' => $shopItemData['type'],
            'next_level' => $shopItemData['next_level'],
            'next_level_experience' => $shopItemData['next_level_experience'],
            'value' => $shopItemData['value'],
            'hidden_value' => $shopItemData['hidden_value'],
        ]);
        $kabanchikSkin = KabanchikSkin::where('name', '=', $shopItemData['egg_type'])->first();
        $kabanchik->kabanchik_skin_id = $kabanchikSkin->id;
        $this->updateKabanchik($kabanchik, $kabanchik->value, $kabanchik->hidden_value, 0);
        return $kabanchik;
    }

    public function unlockKabanchik(Kabanchik $kabanchik): void
    {
        $kabanchik->update(['is_locked' => 0]);
    }

    public function lockKabanchik(Kabanchik $kabanchik): void
    {
        $kabanchik->update(['is_locked' => 1]);
    }

    public function getValueLimit(Kabanchik $kabanchik)
    {
        $levels = [
            0 => 1e16,      //100 0.002911
            1 => 200, //200
            2 => 300, //300
            3 => 600, //600
            4 => 1000, //1000
            5 => 1500, //1500
            6 => 3000, //3000
            7 => 5000, //5000
            8 => 7000, //7000
            9 => 10000, //10000
            10 => 15000, //15000
            11 => 1e12
        ];
        return $levels[$kabanchik->level];
    }

    public function getPopComission(Kabanchik $kabanchik)
    {
        $levels = [
            0 => -1,
            1 => 0.15,
            2 => 0.13,
            3 => 0.12,
            4 => 0.11,
            5 => 0.10,
            6 => 0.09,
            7 => 0.08,
            8 => 0.07,
            9 => 0.06,
            10 => 0.05,
            11 => 0.04
        ];
        return $levels[$kabanchik->level];
    }

    public function updateKabanchik(Kabanchik $kabanchik, float $value, float $hiddenValue, int $addXp)
    {
        $kabanchik->value = $value;
        $kabanchik->hidden_value = $hiddenValue;
        $levels = [
            0 => 144,
            1 => 200,
            2 => 350,
            3 => 600,
            4 => 800,
            5 => 1000,
            6 => 1500,
            7 => 2000,
            8 => 3000,
            9 => 5000,
            10 => 10000,
            11 => 20000
        ];
        $levels = array_reverse($levels, true);
        $kabanchik->experience += $addXp;
        if ($kabanchik->experience >= $kabanchik->next_level_experience) {
            $nextLevel = min(11, max($kabanchik->level + 1, $kabanchik->next_level));
            if ($kabanchik->level == 0) {
                $kabanchikSkin = KabanchikSkin::where([
                    ['type', '=', 'kabanchik'],
                    ['collection', '=', $kabanchik->collection],
                    ['rarity', '=', $kabanchik->rarity],
                ])->inRandomOrder()->first();
                $kabanchik->kabanchik_skin_id = $kabanchikSkin->id;
                $kabanchik->type = 'kabanchik';
            }
            $leftOverXp = $kabanchik->experience - $kabanchik->next_level_experience;
            $kabanchik->experience = $leftOverXp;
            $kabanchik->level = $nextLevel;
            $kabanchik->next_level_experience = $nextLevel == 11 ? 1e9 : $levels[$nextLevel];
            $kabanchik->value_limit = $this->getValueLimit($kabanchik);
            $kabanchik->next_level = min($kabanchik->level + 1, 11);
            if ($kabanchik->level > $kabanchik->user->max_level) {
                $kabanchik->user->update(['max_level' => $kabanchik->level]);
            }
            // TODO: logs, levelup bonuses etc
        }

        if ($kabanchik->top_value < $kabanchik->value) {
            $kabanchik->top_value = $kabanchik->value;
        }

        Log::debug("updateKabanchik(id={$kabanchik->id}, value={$value}, hidden_value={$hiddenValue})");
        $kabanchik->save();
    }

    public function popKabanchik(Kabanchik $kabanchik)
    {
        if ($kabanchik->level < 1) {
            throw new Exception("Must hatch first!");
        }
        $feeRatio = $this->getPopComission($kabanchik);
        $fee = $kabanchik->value * $feeRatio;
        $userReceives = $kabanchik->value - $fee;

        $transaction = $this->walletService->sellForOglc($kabanchik->user, $userReceives);
        if (!$transaction) {
            throw new Exception("Failed to create pop kabanchik transaction! Try again later");
        }
        $transaction->update([
            'comment' => 'kabanchik:'.$kabanchik->id.',value:'.$kabanchik->value
        ]);
        $kabanchik->update(['is_locked' => 1, 'risk' => 0]);
        return $transaction;
    }

    public function finishPoppingKabanchik(Transaction $transaction)
    {
        $transactionData = explode(',', $transaction->comment);
        $data = [];
        foreach ($transactionData as &$chunk) {
            $chunkData = explode(':', $chunk);
            if (count($chunkData) != 2) {
                return;
            }
            list($key, $value) = $chunkData;
            $data[$key] = $value;
        }
        if (!isset($data['kabanchik'])) {
            $kabanchik = Kabanchik::where([['user_id', '=', $transaction->user_id],
                                   ['is_locked', '=', 1]]);
        } else {
            $kabanchik = Kabanchik::findOrFail($data['kabanchik']);
        }
        if ($transaction->status === 'fail') {
            $kabanchik->update(['is_locked' => 0]);
        } else if ($transaction->status === 'success') {
            // TODO ws notification "Kabanchik pop successful"
            $kabanchik->update(['value' => 0]);
            $this->websocketService->sendMessage($kabanchik->user_id, [
                'event' => 'pop_kabanchik',
                'transaction_id' => $transaction->id,
                'kabanchik_id' => $kabanchik->id,
                'amount' => $transaction->amount
            ]);
        }
    }


    public function cancelPoppingKabanchik(Transaction $transaction)
    {
        $data = transactionDataToArray($transaction->comment);
        if (!isset($data['kabanchik'])) {
            $kabanchik = Kabanchik::where([['user_id', '=', $transaction->user_id],
                                   ['is_locked', '=', 1]]);
        } else {
            $kabanchik = Kabanchik::findOrFail($data['kabanchik']);
        }
        $kabanchik->update(['is_locked' => 0]);
    }


    public function getItems(?Kabanchik $kabanchik)
    {
        if (!$kabanchik) {
            return [];
        }
        $topValue = Kabanchik::where('user_id', '=', $kabanchik->user_id)->max('top_value');
        $items = [];
        $itemValues = [
            'shoes' => 100,
            'pants' => 200,
            'gloves' => 300,
            'jacket' => 400,
            'hat' => 500,
            'phone' => 600,
        ];
        foreach ($itemValues as $itemName => $value) {
            if ($kabanchik->top_value >= $value) {
                $items []= $itemName;
            }
        }
        return $items;
    }

    public function getKabanchikForUser(User $user)
    {
        return Kabanchik::where([
            ['user_id', '=', $user->id],
            ['value', '>=', KabanchikGameService::MIN_BET]
        ])->first();
    }

    public function getKabanchiksForUser(User $user)
    {
        return Kabanchik::where([
            ['user_id', '=', $user->id],
            ['value', '>=', KabanchikGameService::MIN_BET]
        ])->get();
    }

    public function process()
    {

    }
}
