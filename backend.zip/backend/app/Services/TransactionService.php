<?php
namespace App\Services;

use App\Models\User;
use App\Models\Kabanchik;
use App\Models\Transaction;
use Carbon\Carbon;

class TransactionService
{
    public function processTransaction(User $user, Transaction $transaction)
    {
        if ($transaction->type == 'buy_kabanchik') {
            if ($user->wallet_balance < -$transaction->amount) {
                throw new Exception("Insufficient funds");
            }
            // TODO signs
            $user->wallet_balance += $transaction->amount;
            // $user->balance -= $transaction->amount;
        } else if ($transaction->type == 'pop_kabanchik') {
            // $user->balance -= $transaction->amount;
            $user->wallet_balance += $transaction->amount;
        }
        // TODO withdraw, replenish etc
        $user->save();
        $transaction->save();
    }

    public function getKabanchikTransactions(Kabanchik $kabanchik, bool $hideZeros=false)
    {
        if ($hideZeros) {
            $transactions = Transaction::where('kabanchik_id', '=', $kabanchik->id)
                ->whereIn('type', ['bet', 'win'])
                ->whereNotNull('game_id')
                ->orderBy('id', 'desc')
                ->take(400)
                ->get();
            $transactionsByGameId = [];
            $gameIds = [];
            $returnTransactions = [];
            foreach ($transactions as &$transaction) {
                if (!isset($transactionsByGameId[$transaction->game_id])) {
                    $gameIds []= $transaction->game_id;
                    $transactionsByGameId[$transaction->game_id] = [];
                }
                $transactionsByGameId[$transaction->game_id] []= $transaction;
            }
            for ($i=0; $i<count($gameIds); $i++) {
                $gameId = $gameIds[$i];
                $nTransactionsForGame = count($transactionsByGameId[$gameId]);
                $tenSecondsAgo = Carbon::now()->subSeconds(1);
                if ($nTransactionsForGame == 1
                        && $transactionsByGameId[$gameId][0]->created_at < $tenSecondsAgo
                        && abs($transactionsByGameId[$gameId][0]->amount) >= 1e-18) {
                    $returnTransactions []= $transactionsByGameId[$gameId][0];
                } else if ($nTransactionsForGame == 2) {
                    $sum = 0;
                    foreach ($transactionsByGameId[$gameId] as &$transaction) {
                        $sum += $transaction->amount;
                    }
                    if (abs($sum) > 1e-18) {
                        $returnTransactions []= $transactionsByGameId[$gameId][0];
                        $returnTransactions []= $transactionsByGameId[$gameId][1];
                    }
                }
            }
            return $returnTransactions;
        } else {
            return Transaction::where('kabanchik_id', '=', $kabanchik->id)
                ->whereIn('type', ['bet', 'win'])
                ->whereNotNull('game_id')
                ->orderBy('id', 'desc')
                ->take(400)
                ->get();
        }
    }

    public function getKabanchikChart(Kabanchik $kabanchik, bool $hideZeros=false)
    {
        if ($hideZeros) {
            $transactions = Transaction::where('kabanchik_id', '=', $kabanchik->id)
                ->whereIn('type', ['bet', 'win'])
                ->whereNotNull('game_id')
                ->orderBy('id', 'desc')
                ->take(400)
                ->get();
            $transactionsByGameId = [];
            $gameIds = [];
            $returnTransactions = [];
            foreach ($transactions as &$transaction) {
                if (!isset($transactionsByGameId[$transaction->game_id])) {
                    $gameIds []= $transaction->game_id;
                    $transactionsByGameId[$transaction->game_id] = [];
                }
                $transactionsByGameId[$transaction->game_id] []= $transaction;
            }
            for ($i=0; $i<count($gameIds); $i++) {
                $gameId = $gameIds[$i];
                $nTransactionsForGame = count($transactionsByGameId[$gameId]);
                $tenSecondsAgo = Carbon::now()->subSeconds(1);
                if ($nTransactionsForGame == 1
                        && $transactionsByGameId[$gameId][0]->created_at < $tenSecondsAgo
                        && abs($transactionsByGameId[$gameId][0]->amount) >= 1e-18) {
                    $returnTransactions []= $transactionsByGameId[$gameId][0];
                } else if ($nTransactionsForGame == 2) {
                    $sum = 0;
                    foreach ($transactionsByGameId[$gameId] as &$transaction) {
                        $sum += $transaction->amount;
                    }
                    if (abs($sum) > 1e-18) {
                        $returnTransactions []= $transactionsByGameId[$gameId][0];
                        $returnTransactions []= $transactionsByGameId[$gameId][1];
                    }
                }
            }
            return $returnTransactions;
        } else {
            return Transaction::where('kabanchik_id', '=', $kabanchik->id)
                ->whereIn('type', ['bet', 'win'])
                ->whereNotNull('game_id')
                ->orderBy('id', 'desc')
                ->take(400)
                ->get();
        }
    }

    public function getPendingTransactions(User $user)
    {
        return Transaction::where([['user_id', '=', $user->id],
                                   ['status', '=', 'pending']])
                          ->orderBy('id', 'desc');
    }
}
