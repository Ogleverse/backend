<?php
namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Redis;

/**
 * Websocket notifications service
 */
class WebsocketService
{
    const ALL_USERS = -1;

    public function __construct()
    {
        $this->socket = \socket_create(\AF_INET, \SOCK_STREAM, \SOL_TCP);
        $this->isConnected = false;
    }

    private function connect()
    {
        try {
            $this->isConnected = \socket_connect($this->socket, env('WS_SERVER_CONTROL_HOST'), env('WS_SERVER_CONTROL_PORT'));
        } catch (\ErrorException $e) {
            $this->isConnected = false;
        }
    }

    public function __destruct()
    {
        if ($this->isConnected) {
            \socket_close($this->socket);
        }
    }

    /**
     * Send notification to the specified user or all users
     * @param  int    $userId  User ID or -1 for broadcasting
     * @param  array  $payload Payload array
     */
    public function sendMessage(int $userId, array $payload): void
    {
        $this->connect();
        if (!$this->isConnected) return;
        $commandToWsServer = [
            'method' => 'notify',
            'user_id' => $userId == -1 ? '*' : $userId,
            'payload' => $payload
        ];
        $buffer = json_encode($commandToWsServer, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        \socket_write($this->socket, $buffer, strlen($buffer));
    }

    public function getWebsocketAuthToken(User $user)
    {
        $token = Redis::get('userWsAuthToken:'.$user->id);
        if ($token) {
            Redis::expire('userWsAuthToken:'.$user->id, 86400);
            Redis::expire('userIdByToken:'.$token, 86400);
        } else {
            $token = $this->createWebSocketAuthToken($user);
        }
        return $token;
    }

    public function createWebSocketAuthToken(User $user)
    {
        $token = \base64_encode(\openssl_random_pseudo_bytes(32));
        Redis::set('userWsAuthToken:'.$user->id, $token, 86400);
        Redis::set('userIdByToken:'.$token, $user->id, 86400);
        return $token;
    }
}

?>
