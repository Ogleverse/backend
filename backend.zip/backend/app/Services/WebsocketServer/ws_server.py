#!/usr/bin/env python3

import sys
import signal
import asyncio
import websockets
import redis
import json
import logging
import traceback
import os
from time import sleep
# from configparser import ConfigParser
from dotenv import load_dotenv
from wsserver.client import WSClient
from wsserver.db import Database, RedisCache
from wsserver.notification import Notifications
from wsserver.util import is_int

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(message)s')

clients = set()
loop = None
app = None


class WebSocketServerApp:
    def __init__(self, cfgname):
        with open(cfgname) as f:
            load_dotenv(stream=f)
        self.conf = {
            'redis': {
                'host': os.getenv('REDIS_HOST'),
                'port': os.getenv('REDIS_PORT'),
                'db': 0,
                'password': os.getenv('REDIS_PASSWORD'),
            },
            'mysql': {
                'host': os.getenv('DB_HOST'),
                'port': os.getenv('DB_PORT'),
                'dbase': os.getenv('DB_DATABASE'),
                'user': os.getenv('DB_USERNAME'),
                'passwd': os.getenv('DB_PASSWORD'),
            },
            'sock': {
                'addr': os.getenv('WS_SERVER_CONTROL_HOST'),
                'port': os.getenv('WS_SERVER_CONTROL_PORT'),
            },
            'websocket': {
                'addr': os.getenv('WS_SERVER_LISTEN_HOST'),
                'port': os.getenv('WS_SERVER_LISTEN_PORT'),
            },
        }
        # self.conf.read(cfgname)
        self.db = Database(self)
        self.redis = RedisCache(self)
        self.Notifications = Notifications(self)

    def log(self, msg):
        logging.log(msg)


async def subscribe_user(cli, msg):
    print("subscribe_user", msg)
    if 'token' not in msg:
        return False
    red = redis.StrictRedis()
    rkey = f'userIdByToken:{msg["token"]}'
    user_id = red.get(rkey)
    if not user_id:
        await cli.send({'event': 'subscribe', 'success': False, 'rkey': rkey})
        return False
    else:
        user_id = int(user_id)
    print(' :: subscribe_user', rkey, user_id)
    red.expire(rkey, 86400)
    red.expire('userWsAuthToken:{}'.format(user_id), 86400)
    await app.Notifications.subscribe(user_id, msg['token'], cli)
    return user_id


async def sync_user(cli, msg):
    user_id = await subscribe_user(cli, msg)
    print("\033[1;33m", f'subscribe uid={user_id}', cli, "\033[m")
    if not user_id:
        return
    await app.Notifications.drain(user_id)


async def ack(cli, msg):
    if 'nonce' not in msg or type(msg['nonce']) is not str:
        return False
    await app.Notifications.Ack(
        app.Notifications.user_id_by_sock(cli),
        msg['nonce'])

handlers = {
    "subscribe": sync_user,
    "sync": sync_user,
    "ack": ack,
    }


async def serve(wsock, path):
    """
    Calls handlers[message.method](WSClient, dict)
    """
    global clients
    global handlers
    cli = WSClient(wsock)
    clients.add(cli)
    print('\033[1;31m', 'serve', cli, wsock, '\033[m')
    logging.info("\033[1;32mCLIENTS\033[m")
    i = 0
    for client_ in clients:
        print(f'client {i}', client_)
        i += 1
    while True:
        try:
            rcv = await wsock.recv()
            msg = json.loads(rcv)
            if msg["method"] in handlers:
                try:
                    await handlers[msg["method"]](cli, msg)
                except:
                    logging.info(sys.exc_info())
                    logging.info(traceback.extract_tb(sys.exc_info()[2]))
            else:
                logging.warn("Unknown method "+msg["method"])
        except websockets.exceptions.ConnectionClosed:
            logging.info("serve(...) ConnectionClosed")
            await wsock.close()
            if cli in clients:
                clients.remove(cli)
            break
        except:
            logging.info("serve(...) Exception")
            logging.info(sys.exc_info())
            logging.info(traceback.extract_tb(sys.exc_info()[2]))


async def tcp_manage(reader, writer):
    logging.debug("tcp_manage(...)")
    try:
        pkt = await reader.read(16384)
        if pkt:
            try:
                data = json.loads(pkt.decode().strip())
                cmd = data['method']
            except:
                cmd = False
            if cmd == "notify":
                (user_id, payload) = [data['user_id'], data['payload']]
                data = json.dumps(data['payload'], ensure_ascii=False)
                await app.Notifications.Send(user_id, payload)
            elif cmd == 'unsubscribe':
                token = data['token']
                red = redis.StrictRedis()
                rkey = 'userIdByToken:{}'.format(token)
                user_id = red.get(rkey)
                if user_id:
                    red.delete(rkey)
                    red.delete('userWsAuthToken:{}'.format(user_id))
                await app.Notifications.unsubscribe_token(token)
                writer.write('{"unsubscribe":"ok"}'.encode())
            else:
                writer.write('{"error":"unrecognized command"}'.encode())
            await writer.drain()
    except:
        logging.debug(sys.exc_info())
        logging.debug(traceback.extract_tb(sys.exc_info()[2]))
    finally:
        writer.close()
    sleep(0.5)


def SIGINT_handler(signal, frame):
    shutdown = True
    global loop
    loop.close()


if __name__ == "__main__":
    signal.signal(signal.SIGINT, SIGINT_handler)
    app = WebSocketServerApp(
        os.path.join(
            os.path.dirname(os.path.realpath(__file__)),
            '../../../.env')
            )
    logging.info("fgsfds")
    loop = asyncio.get_event_loop()
    start_server = websockets.serve(serve,
                                    app.conf["websocket"]["addr"],
                                    app.conf["websocket"]["port"])
    start_tcp_manage = asyncio.start_server(tcp_manage,
                                            app.conf["sock"]["addr"],
                                            int(app.conf["sock"]["port"]),
                                            loop=loop)
    loop.run_until_complete(asyncio.gather(start_server, start_tcp_manage))
    loop.run_forever()
