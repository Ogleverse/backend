import traceback
import random
from collections import defaultdict, deque
from functools import partial
from wsserver.db import *
from time import time


def randomString(stringLength=6):
    letters = 'qwertyuiopasdfghjklzxcvbnm1234567890'
    return ''.join(random.choice(letters) for i in range(stringLength))


class Notifications:
    usersocks = {}
    messages_queue = defaultdict(partial(deque, maxlen=255))

    def __init__(self, app):
        self.sock_by_token = {}
        self._app = app

    def user_id_by_sock(self, client):
        for key in self.usersocks:
            if self.usersocks[key] == client:
                return key
        return None

    async def subscribe(self, key, token, client):
        key = str(key)
        print(' :: async subscribe', f'key={key} token={token}', client)
        if key in self.usersocks:
            print(' ::     remove old client', f'key={key}', self.usersocks[key])
            await self.unsubscribe(key, self.usersocks[key])
        self.usersocks[str(key)] = client
        self.sock_by_token[token] = (key, client)
        await self.Send(key, {'event': 'subscribe',
                              'success': True,
                              'user_id': str(key)}, immediately=True)

    async def unsubscribe_token(self, token):
        if token not in self.sock_by_token:
            return
        (key, client) = self.sock_by_token[token]
        del self.sock_by_token[token]
        await self.unsubscribe(key, client)

    async def unsubscribe(self, key, client):
        key = str(key)
        if key not in self.usersocks:
            return
        del self.usersocks[key]
        await client.send({'event':'unsubscribed',
                           'nonce': 'no_nonce'})

    async def Send(self, key, message, nonce=None, immediately=False):
        key = str(key)
        print(f' -> async Send key={key}', key in self.usersocks, message)
        for key_ in self.usersocks:
            print(f'    {key_}', self.usersocks[key_])
        if key not in self.usersocks and key != '*':
            traceback.print_stack()
        if key == '*':
            for key in self.usersocks.keys():
                await self.Send(key, message, nonce)
            return
        if key not in self.usersocks:
            return
        # if nonce is None or any([x['nonce'] == nonce for x in self.messages_queue[key]]):
        if immediately:
            if key not in self.usersocks:
                return
            message['_nonce'] = randomString()
            await self.usersocks[key].send(message)
            return
        if (len(self.messages_queue[key]) > 1
            and (self.messages_queue[key][0]['nonce'] == 'refresh'
                 or len(self.messages_queue[key]) == self.messages_queue[key].maxlen)):
            self.messages_queue[key].clear()
            self.messages_queue[key].append({
                'nonce': 'refresh',
                'message': {
                    'event': 'refresh'
                }
            })
        else:
            self.messages_queue[key].append({
                'nonce': randomString(),
                'message': message
            })
        await self.drain(key)
        if message['event'] == 'logout':
            self.messages_queue[key].clear()

    async def drain(self, key):
        if key not in self.messages_queue or key not in self.usersocks:
            return
        cli = self.usersocks[key]
        for data in self.messages_queue[key]:
            message = data['message']
            message['_nonce'] = data['nonce']
            await cli.send(message)

    async def Ack(self, key, nonce):
        if key not in self.messages_queue:
            return False
        user_msg_queue = self.messages_queue[key]
        for i in range(len(user_msg_queue)):
            if (user_msg_queue[i]['nonce'] == nonce):
                del user_msg_queue[i]
                return True
        return False
