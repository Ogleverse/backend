import pymysql
import redis
import logging
import sys
import traceback


class Database:
    def __init__(self, app):
        self._app = app
        self.mysql = None

    def get_mysql(self):
        if self.mysql is None:
            self.mysql = pymysql.connect(host=self._app.conf["mysql"]["host"],
                                         port=int(self._app.conf["mysql"]["port"]),
                                         user=self._app.conf["mysql"]["user"],
                                         passwd=self._app.conf["mysql"]["passwd"],
                                         db=self._app.conf["mysql"]["dbase"],
                                         charset='utf8')
        return self.mysql

    def insert_id(self):
        conn = self.get_mysql()
        return conn.insert_id()

    def exec_query(self, query, params):
        conn = self.get_mysql()
        try:
            with conn.cursor() as cur:
                cur.execute(query, params)
                res = cur.fetchall()
        except:
            logging.debug(sys.exc_info())
            logging.debug(traceback.extract_tb(sys.exc_info()[2]))
            return None
        cur.close()
        conn.close()
        self.mysql = None
        return res


class RedisCache:
    def __init__(self, app):
        self.red = None
        self._app = app

    def get_redis(self):
        if self.red is None:
            self.red = redis.StrictRedis(host=self._app.config["redis"]["host"],
                                         port=int(self._app.conf["redis"]["port"]),
                                         db=int(self._app.conf["redis"]["db"]))
        return self.red
