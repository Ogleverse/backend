def is_int(data):
    if type(data) is int:
        return True
    try:
        int(data)
    except ValueError:
        return False
    return True
