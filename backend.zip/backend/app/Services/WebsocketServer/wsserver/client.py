import sys
import traceback
import json
import logging

class WSClient:
    def __init__(self, ws):
        self.alive = True
        self.ws = ws
    
    async def send(self, message):
        logging.info(("WSClient.send:", self.alive, message))
        if not self.alive:
            return False
        try:
            await self.ws.send(json.dumps(message))
            return True
        except:
            self.alive = False
            return False
