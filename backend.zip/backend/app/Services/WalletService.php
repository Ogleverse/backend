<?php
namespace App\Services;

use Exception;
use Illuminate\Support\Facades\Http;
use App\Exceptinos\InsufficientOGLCException;
use App\Exceptinos\InsufficientBNBException;
use App\Events\TransactionStatusUpdated;
use App\Models\Transaction;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class WalletService
{
    public function __construct()
    {
        // $this->httpClient = nwe
        $this->url = env('BNB_SERVICE_URL');
    }

    private function ensureUserWalletExists(int $userId)
    {
        try {
            $response = Http::get($this->url."/user-wallets/$userId");
            if ($response->status() == 404) {
                $response = Http::put($this->url."/user-wallets/$userId");
                if ($response->status() != 200) {
                    return false;
                }
                return true;
            }
            return $response->status() == 200;
        } catch (Exception $e) {
            return false;
        }
    }

    public function getUserWalletInfo(int $userId)
    {
        $walletExists = $this->ensureUserWalletExists($userId);
        if (!$walletExists) {
            // throw new Exception("Failed to retrieve user wallet info");
            return [
                'blockchain_address' => 'Failed to retrieve user wallet info',
                'balance' => -1.0,
                'error' => 'Failed to retrieve user wallet info'
            ];
        }

        try {
            $response = Http::get($this->url."/user-wallets/$userId");
            if ($response->status() == 200) {
                try {
                    $json = $response->json();
                    return $json;
                } catch (Exception $e) {}
            }
        } catch (Exception $e) {}

        return [
            'blockchain_address' => 'Failed to retrieve user wallet info',
            'balance' => -1.0,
            'error' => 'Failed to retrieve user wallet info'
        ];
    }

    public function processTransaction(iterable $data)
    {
        $transactionStatus = $data['successful'] ? 'success' : 'fail';
        $transaction = false;
        if (isset($data['transaction_id'])) {
            if (\is_numeric($data['transaction_id'])) {
                $transaction = Transaction::find($data['transaction_id']);
                $transaction->status = $transactionStatus;
            } else {
                $lastChar = $data['transaction_id'][strlen($data['transaction_id']) - 1];
                if ($lastChar == 'b' || $lastChar == 'c') {
                    if ($data['successful']) {
                        $transaction = Transaction::find(substr($data['transaction_id'], 0, strlen($data['transaction_id']) - 1));
                        $transaction->update(['comment' => $transaction->comment . ',+'.$lastChar]);
                        if (strpos($transaction->comment, ',+b') !== false && strpos($transaction->comment, ',+c') !== false) {
                            $response = Http::post($this->url."/transactions/".$transaction->id);
                            $status = $response->status() == 200
                                ? 'pending'
                                : 'fail';
                            $transaction->update([
                                'status' => $status,
                                'comment' => str_replace([',+b', ',+c'], ['', ''], $transaction->comment)
                            ]);
                        }
                    } else {
                        $transaction = Transaction::find(substr($data['transaction_id'], 0, strlen($data['transaction_id']) - 1));
                        // $transactionData = transactionDataToArray($transaction->comment);
                        // if (isset($transactionData['kabanchik'])) {
                        //     $kabanchik = Kabanchik::find($transactionData['kabanchik']);
                        //     if ($transaction->type == 'pop_kabanchik')
                        //         $kabanchik->update(['is_locked' => 0]);
                        //     else
                        //         $kabanchik->delete();
                        // }
                        $transaction->update(['status' => 'fail']);
                    }
                }
            }
            // if ($transaction->type == 'buy') {
            //     $this->shopService->finishPurchase($transaction);
            // }
        } else {
            return;
            $transaction = Transaction::make([
                'user_id' => (isset($data['user']['id']) && $data['user']['id']) ? $data['user']['id'] : null,
                'kabanchik_id' => null,
                'game_id' => null,
                'game_entry_id' => null,
                'amount' => $data['amount'],
                'type' => 'replenishment',
                'status' => $transactionStatus
            ]);
        }
        if (!$transaction)
            return;
        $transaction->save();

        TransactionStatusUpdated::dispatch($transaction);

        /*
        if (isset($data['user']['id']) && $data['user']['id']) {
            $user = User::find($data['user']['id']);
            $user->update([
                'balance_bnb' => wei2amount($data['user']['balance']['bnb']),
                'balance_oglc' => wei2amount($data['user']['balance']['oglc']),
            ]);
            $websocketService = app(\App\Services\WebsocketService::class);
            $websocketService->sendMessage($data['user']['id'], [
                'event' => 'balance_update',
                'balance_bnb' => wei2amount($data['user']['balance']['bnb']),
                'balance_oglc' => wei2amount($data['user']['balance']['oglc']),
            ]);
        }
        */
       if ($transaction->user_id) {
           $user = User::find($transaction->user_id);
           $info = $this->getUserWalletInfo($user->id);
           if (\is_numeric($info['balance']) && $info['balance'] < 0) {
               return;
           }
           $user->update([
               'balance_bnb' => \wei2amount($info['balance']['bnb']),
               'balance_oglc' => \wei2amount($info['balance']['oglc']),
           ]);
       }
    }

    public function getExchangeRates($user)
    {
        try {
            $response = Http::get($this->url.'/user-wallets/'.$user->id.'/exchange');
            if ($response->status() != 200) {
                return false;
            }
            return $response->json();
        } catch (Exception $e) {
            return false;
        }
    }

    public function convert(string $currencyFrom, string $currencyTo, string $amount, bool $includeFees=true): string
    {
        $rates = $this->getExchangeRates();
        if (!$rates) {
            throw new Exception("Unable to fetch exchange rates");
        }
        if ($currencyFrom == 'bnb' && $currencyTo == 'oglc') {
            $multiplier = $rates['oglc'];
        } else if ($currencyFrom == 'oglc' && $currencyTo == 'bnb') {
            $multiplier = bcdiv(1, $rates['oglc']);
        } else {
            throw new Exception("Invalid coin pair");
        }
        $amount = bcmul($amount, $multiplier);
        if ($includeFees) {
            $amount = bcmul($amount, bcsub('1', ''.$rates['comission']));
        }
        return $amount;
    }

    public function exchange($user, $currencyFrom, $currencyTo, $amount, $includeFees=true)
    {
        $rates = $this->getExchangeRates();
        if (!$rates) {
            throw new Exception("Unable to fetch exchange rates");
        }
        if (($currencyFrom == 'oglc' && !$rates['exchange']['oglc_bnb'])
            || ($currencyFrom == 'bnb' && !$rates['exchange']['bnb_oglc'])) {
                throw new Exception("Exchange $currencyTo to $currencyFrom is temporarily unavailable");
            }
        if ($currencyFrom == 'oglc' && $currencyTo == 'bnb') {
            if ($user->balance_oglc < $amount) {
                throw new InsufficientOGLCException("Insufficient OGLC");
            }
            $multiplier = bcdiv('1', $rates['oglc']);
            $fee = bcmul(''.$rates['comission'], $amount);
            $amountFrom = bcsub($amount, $fee);
            $amountTo = bcmul($amountFrom, $multiplier);
        } else if ($currencyFrom == 'bnb' && $currencyTo == 'oglc') {
            if ($user->balance_bnb < $amount) {
                throw new InsufficientBNBException("Insufficient BNB");
            }
            $multiplier = bcmul('1', $rates['oglc']);
            $fee = bcmul(''.$rates['comission'], $amount);
            $amountTo = bcdiv(bcsub($amount, $fee), $rates['bnb']);
        } else {
            throw new Exception("Invalid coin pair");
        }

        $feeTransaction = Transaction::create([
            'type' => 'fee',
            'currency' => $currencyFrom,
            'user_id' => $user->id,
            'amount' => $amount,
        ]);
        $transaction = Transaction::create([
            'type' => 'exchange',
            'currency' => $currencyFrom,
            'user_id' => $user->id,
            'amount' => $amount,
            'comment' => 'rate:'.$multiplier.',fee_id:'.$feeTransaction->id
        ]);

        try {
            $response = Http::post($this->url.'/user-wallets/'.$user->id.'/exchange', [
                'transaction_id' => $transaction->id,
                'exchange' => $currencyFrom
            ]);
            if ($response->status != 200) {
                $transaction->update(['status' => 'fail']);
                return false;
            }
            return $response->json();
        } catch (Exception $e) {
            return false;
        }
        return $transaction;
    }

    // "withdraw" transaction, user_wallet -> outside
    public function withdraw($user, $currency, $amount, $address, $gas)
    {
        $walletExists = $this->ensureUserWalletExists($user->id);
        if (!$walletExists) {
            throw new Exception("User wallet seems to not exist");
        }
        if ($currency != 'bnb'&& $currency != 'oglc') {
            throw new Exception("Invalid currency. Available: bnb, oglc");
            //throw new Exception("Invalid currency. Available: bnb");
        }
        if ($currency == 'oglc' && $user->balance_oglc < $amount) {
            throw new Exception("Insufficient OGLC balance");
        }
        if ($currency == 'bnb' && $user->balance_bnb < $amount) {
            throw new Exception("Insufficient BNB balance");
        }
        try {
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'withdrawal',
                'currency' => $currency,
                'status' => 'pending',
                'amount' => $amount,
                'comment' => 'withdraw,to:'.$address
            ]);
            $payload = [
                'transaction_id' => $transaction->id,
                'amount' => amount2wei($transaction->amount),
                'to' => $address,
                'currency' => $currency
            ];
            Log::debug("POST /user-wallets/".$user->id."/withdraw".json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $response = Http::post(
                $this->url."/user-wallets/".$user->id."/withdraw",
                $payload);
            if ($response->status() == 200) {
                if ($currency == 'oglc') {
                    $user->update(['balance_oglc' => $user->balance_oglc - $amount]);
                } else if ($currency == 'bnb') {
                    $user->update(['balance_bnb' => $user->balance_bnb - $amount]);
                }
                $transaction->save();
                return $transaction;
            } else {
                $transaction->update(['status' => 'fail']);
                if ($currency == 'oglc') {
                    $user->update(['balance_oglc' => $user->balance_oglc + $amount]);
                } else if ($currency == 'bnb') {
                    $user->update(['balance_bnb' => $user->balance_bnb + $amount]);
                }
                return false;
            }
        } catch (Exception $e) {
            throw $e;
        }
    }

    // "buy" transaction, user_wallet -> game_wallet (BNB)
    /**
     * Creates a "buy" transaction
     * @param  [type]      $user   User that buys
     * @param  [type]      $amount Amount
     */
    public function buyForBnb($user, $amount)
    {
        $walletExists = $this->ensureUserWalletExists($user->id);
        if (!$walletExists) {
            throw new Exception("User wallet seems to not exist");
        }
        if ($user->balance_bnb < $amount) {
            throw new InsufficientBNBException("Insufficient BNB balance");
        }
        // try {
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'buy',
                'currency' => 'bnb',
                'status' => 'pending',
                'amount' => $amount
            ]);
            $payload = [
                'transaction_id' => $transaction->id,
                'amount' => amount2wei($transaction->amount),
                'currency' => 'bnb',
                'from' => $user->id,
            ];
            Log::debug("POST /game-wallet/buy: ".json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $response = Http::post(
                $this->url."/game-wallet/buy",
                $payload);
            if ($response->status() == 200) {
                $user->update(['balance_bnb' => $user->balance_bnb - $amount]);
                $transaction->save();
                return $transaction;
            } else {
                $transaction->update(['status' => 'fail']);
                $user->update(['balance_bnb' => $user->balance_bnb + $amount]);
                return false;
            }
        // } catch (Exception $e) {
        //     return false;
        // }
    }

    // "buy" transaction, user_wallet -> game_wallet (OGLC)
    /**
     * Creates a "buy" transaction
     * @param  [type]      $user   User that buys
     * @param  [type]      $amount Amount
     */
    public function buyForOglc($user, $amount)
    {
        $walletExists = $this->ensureUserWalletExists($user->id);
        if (!$walletExists) {
            throw new Exception("User wallet seems to not exist");
        }
        if ($user->balance_oglc < $amount) {
            throw new InsufficientOGLCException("Insufficient OGLC balance");
        }
        // try {
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'buy',
                'currency' => 'oglc',
                'status' => 'new',
                'amount' => $amount
            ]);
            $payload = [
                'transaction_id' => $transaction->id,
                'amount' => amount2wei($transaction->amount),
                'currency' => 'oglc',
                'from' => $user->id,
            ];
            Log::debug("POST /game-wallet/buy: ".json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $response = Http::post(
                $this->url."/game-wallet/buy",
                $payload);
            if ($response->status() == 200) {
                // $response2 = Http::post($this->url."/transactions/".$transaction->id, []);
                // if ($response2->status() == 200) {
                //     $user->update(['balance_oglc' => $user->balance_oglc - $amount]);
                    // $transaction->update(['status' => 'pending']);
                    return $transaction;
                // } else {
                //     $transaction->update(['status' => 'fail']);
                //     return false;
                // }
            } else {
                $transaction->update(['status' => 'fail']);
                // $user->update(['balance_oglc' => $user->balance_oglc + $amount]);
                return false;
            }
        // } catch (Exception $e) {
        //     return false;
        // }
    }

    public function commitBuyTransaction(Transaction $transaction)
    {
        if ($transaction->status != 'new') return;
        $response = Http::post(
            $this->url."/transactions/".$transaction->id,
            []
        );
        if ($response->status() == 200) {
            $transaction->update(['status' => 'pending']);
            return true;
        }
        return false;
    }

    // "pop_kabanchik" transaction, game_wallet -> user_wallet (BNB)
    public function sellForBnb($user, $amount)
    {
        $walletExists = $this->ensureUserWalletExists($user->id);
        if (!$walletExists) {
            throw new Exception("User wallet seems to not exist");
        }
        try {
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'pop_kabanchik',
                'currency' => 'bnb',
                'status' => 'pending',
                'amount' => $amount
            ]);
            $payload = [
                'transaction_id' => $transaction->id,
                'amount' => amount2wei($transaction->amount),
                'currency' => 'bnb',
                'to' => $user->id,
            ];
            Log::debug("POST /game-wallet/withdraw: ".json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $response = Http::post(
                $this->url."/game-wallet/withdraw",
                $payload);
            if ($response->status() != 200) {
                $transaction->update(['status' => 'fail']);
                return false;
            } else {
                return $transaction;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    // "pop_kabanchik" transaction, game_wallet -> user_wallet (BNB)
    public function sellForOglc($user, $amount)
    {

        $walletExists = $this->ensureUserWalletExists($user->id);
        if (!$walletExists) {
            throw new Exception("User wallet seems to not exist");
        }
        try {
            $transaction = Transaction::create([
                'user_id' => $user->id,
                'type' => 'pop_kabanchik',
                'currency' => 'oglc',
                'status' => 'new',
                'amount' => $amount
            ]);
            $payload = [
                'transaction_id' => $transaction->id,
                'amount' => amount2wei($transaction->amount),
                'currency' => 'oglc',
                'to' => $user->id,
            ];
            Log::debug("POST /game-wallet/withdraw: ".json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
            $response = Http::post(
                $this->url."/game-wallet/withdraw",
                $payload);
            if ($response->status() != 200) {
                $transaction->update(['status' => 'fail']);
                return false;
            } else {
                sleep(2);
                $response = Http::post($this->url."/transactions/".$transaction->id);
                var_dump($response->status());
                if ($response->status() != 200) {
                    $transaction->update(['status' => 'fail']);
                    return false;
                } else {
                    $transaction->update(['status' => 'pending']);
                    return $transaction;
                }
            }
        } catch (Exception $e) {
            throw $e;
            return false;
        }
    }

    /**
     * [confirmTransaction description]
     * @param  Transaction $transaction [description]
     * @return [type]                   [description]
     */
    public function confirmTransaction(Transaction $transaction)
    {
        $response = Http::post($this->url."/transactions/".$transaction->id);
        Transaction::update(['status' => 'pending']);
    }
}
