<?php

namespace App\Actions\Fortify;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Auth\Events\Registered;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array  $input
     * @return \App\Models\User
     */
    public function create(array $input)
    {
        Validator::make($input, [
            'name' => ['required', 'string', 'max:255'],
            'email' => [
                'required',
                'string',
                'email',
                'max:255',
                Rule::unique(User::class),
            ],
            'password' => $this->passwordRules(),
            // 'password' => $this->passwordRules(),
            'skin_id' => ['required', 'integer', 'min:1', 'max:6'],
            'ref_user_id' => ['sometimes', 'integer']
        ])->validate();

        $user =  User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => Hash::make($input['password']),
            'balance' => 0.0,
            'skin_id' => $input['skin_id'],
            'ref_code' => \bin2hex(\openssl_random_pseudo_bytes(10)),
            'ref_user_id' => isset($input['ref_user_id']) ? $input['ref_user_id'] : null
        ]);

        event(new Registered($user));
        return $user;
    }
}
