<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\WalletService;
use App\Models\User;
use App\Models\Transaction;

class TransferBnbFromGameWalletToUserWallet extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'bnb:to-user {user_id} {amount}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Transfer BNB from game wallet to user\'s wallet';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(WalletService $walletService)
    {
        parent::__construct();
        $this->walletService = $walletService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $user = User::findOrFail($this->argument('user_id'));
        $transaction = $this->walletService->sellForBnb($user, $this->argument('amount'));
        if (!$transaction) {
            $this->warn("Failed to create transaction!");
            return;
        }
        $this->info("Transaction created, id=".$transaction->id);
        return 0;
    }
}
