<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;

class IssueRefCodesForAllUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user:initrefs';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Initialize ref codes for all users';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        User::whereNull('ref_code')->each(function ($user) {
            $user->ref_code = bin2hex(\openssl_random_pseudo_bytes(10));
            $user->save();
        });
        return 0;
    }
}
