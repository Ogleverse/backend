<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Transaction;

class ViewTransaction extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'transaction:view {id}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Show transaction details by id';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $transaction = Transaction::findOrFail($this->argument('id'));
        $this->info("Transaction:");
        $this->info("    User ID: ".$transaction->user_id);
        $this->info("    Type: ".$transaction->type);
        $this->info("    Currency: ".$transaction->currency);
        $this->info("    Amount: ".$transaction->amount);
        $this->info("    Status: ".$transaction->status);
        $this->info("    ctime: ".$transaction->created_at);
        $this->info("    mtime: ".$transaction->updated_at);
        return 0;
    }
}
