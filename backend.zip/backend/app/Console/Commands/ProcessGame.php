<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\GameService;
use App\Services\KabanchikGameService;

class ProcessGame extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'game:process';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Updates game state, calculates winnings';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(GameService $gameService, KabanchikGameService $kabanchikGameService)
    {
        parent::__construct();
        $this->gameService = $gameService;
        $this->kabanchikGameService = $kabanchikGameService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
	//for ($i=0; $i<6; $i++) {
            $this->gameService->process();
        //    sleep(9);
        //}
        return 0;
    }
}
