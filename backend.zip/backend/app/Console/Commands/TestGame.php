<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Models\Game;
use App\Services\GameService;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class TestGame extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'game:test';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create a pool of users, a game and run it';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(GameService $gameService)
    {
        parent::__construct();
        $this->gameService = $gameService;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $balances = [1.0, 10.0, 100.0, 1000.0];
        $expectations = [1.0, 10.0, 100.0, 1000.0];
        $users = [];
        $game = $this->gameService->createNewGame();
        for ($i=0; $i < count($balances); $i++) {
            for ($j=0; $j < count($expectations); $j++) {
                $testUser = User::factory()->make();
                $balance = $balances[$i];
                $expects = $expectations[$j];
                $deposit = min($balance, $expects);
                // $expects = ($participant->multiplier-1)*$participant->balance;
                // $participant->multiplier = $expects/$participant->balance + 1;
                $multiplier = $expects/$balance + 1;
                $testUser->multiplier = $multiplier;
                $testUser->wallet_balance = 0;
                $testUser->balance = $balance;
                $testUser->save();
                $users []= $testUser;
                // $ent = $this->gameService->joinGame($game, $testUser, $multiplier, $deposit);
                // print("Added ".$testUser->name."\t"
                //       . "B=".$ent->user->balance
                //       . " m=".$ent->multiplier
                //       . " b=".$ent->deposit
                //       . " e=".$ent->expects
                //       . "\n");
            }
        }
        $game->ends_at = Carbon::now()->subMinutes(1);
        $game->save();
        $this->gameService->process($game);
        $game->load('gameEntries');
        $totalDeposited = 0.0;
        $totalWinnings = 0.0;
        print(
            sprintf("%40s", 'User Name')
            . "\t"
            . sprintf("%10s", "balBefr")
            . "\t"
            . sprintf("%10s", 'Deposit')
            . "\t"
            . sprintf("%10s", 'Mult')
            . "\t"
            . sprintf("%10s", "bet/win")
            . "\t"
            . sprintf("%10s", 'res')
            . "\t"
            . sprintf("%10s", 'BalAfter')
            . "\n"
        );
        $totalDeposits = $game->gameEntries->sum('deposit');
        $totalResults = $game->gameEntries->sum('result');
        #$totalLost = $game->gameEntries->sum('deposit', '+', 'result');
        $totalLost = DB::table('game_entries')
            ->where('game_id', '=', $game->id)
            ->sum(DB::raw('deposit - result'));
        foreach ($game->gameEntries as &$entry) {
            $balanceBefore = $entry->user->balance + $entry->deposit - $entry->result;
            $balanceAfter = $entry->user->balance;
            $deposit = $entry->deposit;
            $multiplier = $entry->multiplier;
            $betwin = $entry->result - $deposit;
            $totalDeposited += $entry->deposit;
            $totalWinnings += $entry->result;
            print(
                sprintf("%40s", $entry->user->name)
                . "\t"
                . sprintf("%10s", sprintf('%0.3f', $balanceBefore))
                . "\t"
                . sprintf("%10s", '-'.sprintf('%0.3f', $deposit))
                . "\t"
                . sprintf("%10s", 'x'.sprintf('%0.3f', $multiplier))
                . "\t"
                . ($betwin<0?"\033[1;31m":"\033[1;32m")
                . sprintf("%10s", sprintf('%0.3f', $betwin))
                . "\033[m"
                . "\t"
                . '->'
                . sprintf("%10s", sprintf('%0.3f', $entry->result))
                . "\t"
                . '->'
                . sprintf("%10s", sprintf('%0.3f', $balanceAfter))
                . "\n"
            );
            // $entry->forceDelete();
        }
        print("Total deposits: $totalDeposited\n");
        print("Total winnigns: $totalWinnings\n");
        print("Lost: ".($totalDeposited - $totalWinnings)."\n");
        print("Total deposits (DB): $totalDeposits\n");
        print("Total winnigns (DB): $totalResults\n");
        print("Lost (DB): $totalLost\n");
        // print("Lost (DB): ".(ceil(($totalDeposits - $totalResults)*1e8))/1e8."\n");
        // $game->forceDelete();
        // foreach ($users as &$user) {
        //     $user->forceDelete();
        // }
        return 0;
    }
}
