<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\UserResource;
use App\Models\Transaction;
use App\Models\User;
use App\Services\WalletService;
use App\Exceptions\InsufficientBNBException;
use App\Exceptions\InsufficientOGLCException;
use Illuminate\Support\Facades\Log;

class WalletController extends Controller
{
    public function __construct(WalletService $walletService)
    {
        $this->walletService = $walletService;
    }

    public function replenish(Request $request)
    {
        return [];
            /*
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:1.0']
        ]);
        Transaction::create([
            'user_id' => $request->user()->id,
            'amount' => $validated['amount'],
            'type' => 'replenishment'
        ]);
        $request->user()->wallet_balance += $validated['amount'];
        $request->user()->save();
        return jsonResponse(new UserResource($request->user()));*/
    }

    public function withdraw(Request $request)
    {
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.001'],
            // 'currency' => ['required', 'string', 'in:oglc,bnb'],
            'to_address' => ['required', 'string'],
            'gas' => ['required', 'numeric', 'min:0']
        ]);
        //if (($validated['amount'] + $validated['gas']) <= $request->user()->balance_bnb) {
        // $validated['currency'] = 'bnb';
        $walletService = app(\App\Services\WalletService::class);
        $validated['currency'] = 'oglc';
        $info = $walletService->getUserWalletInfo($request->user()->id);
        // if (($validated['amount'] + $validated['gas']) <= $request->user()->balance_oglc) {
            // Transaction::create([
            //     'user_id' => $request->user()->id,
            //     'amount' => $validated['amount'],
            //     'type' => 'withdrawal'
            // ]);
            try {
                $x = $this->walletService->withdraw($request->user(), $validated['currency'], $validated['amount'],
                    $validated['to_address'], $validated['gas']);
            } catch (Exception $e) {
                return jsonResponse(null, 500, $e->getMessage());
            }
            return jsonResponse(new UserResource($request->user()));
        // } else {
        //     return jsonResponse(null, 422, "Trying to withdraw more than is left on the account balance");
        // }
    }

    public function getExchangeRates(Request $request)
    {
        $rates = $this->walletService->getExchangeRates($request->user());
        if (!$rates) {
            return jsonResponse(null, 500, "Unable to get exchange rates");
        }
        return \jsonResponse($rates);
    }

    public function exchange(Request $request)
    {
        $validated = $request->validate([
            'amount' => ['required', 'string'],
            'from_currency' => ['required', 'string', 'in:oglc,bnb'],
            'to_currency' => ['required', 'string', 'in:oglc,bnb'],
        ]);
        try {
            $transaction = $this->walletService->exchange(
                $request->user(), $validated['from_currency'], $validated['to_currency'], $validated['amount']
            );
        } catch (Exception $e) {
            return jsonResponse(null, 422, $e->getMessage());
        } catch (InsufficientBNBException $e) {
            return jsonResponse(null, 422, $e->getMessage());
        } catch (InsufficientOGLCException $e) {
            return jsonResponse(null, 422, $e->getMessage());
        }
        if ($transaction === false) {
            return jsonResponse(null, 500, "Failed to create exchange transaction");
        }
        return \jsonResponse(new TransactionResource($transaction));
    }

    public function info(Request $request)
    {
        // $walletService = app('App\Services\WalletService');
        $walletService = $this->walletService;
        $info = $walletService->getUserWalletInfo($request->user()->id);
        if (\is_numeric($info['balance']) && $info['balance'] < 0) {
            return \jsonResponse([
                'balance' => [
                    'bnb' => $request->user()->balance_bnb,
                    'oglc' => $request->user()->balance_oglc,
                ],
                'address' => "[disconnected]"
            ]);
        }
        // dd($info);
        $request->user()->update([
            'balance_bnb' => \wei2amount($info['balance']['bnb']),
            'balance_oglc' => \wei2amount($info['balance']['oglc']),
        ]);
        return \jsonResponse($info);
    }

    public function webHook(Request $request, string $secret)
    {
        if ($secret != config('app.bnb.secret')) {
            die();
        }
        Log::debug("Wallet webhook: ".$request->getContent());
        $validated = $request->validate([
            'transaction_id' => ['sometimes'],
            'type' => ['required', 'string'],
            'successful' => ['required', 'boolean'],
            'gasPaid' => ['sometimes'],
            'from' => ['sometimes'],
            'to' => ['sometimes'],
            // 'user.id' => ['sometimes', 'integer', 'exists:users,id'],
            // 'user.balance.bnb' => ['required', 'string'],
            // 'user.balance.oglc' => ['required', 'string'],
            // 'user.address' => ['required', 'string']
        ]);
        Log::debug("Wallet webhook: ".json_encode($validated,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
        $this->walletService->processTransaction($validated);
    }
}
