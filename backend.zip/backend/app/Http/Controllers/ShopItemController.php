<?php

namespace App\Http\Controllers;

use App\Models\ShopItem;
use Illuminate\Http\Request;
use App\Http\Resources\ShopItemResource;
use App\Http\Resources\TransactionResource;
use App\Services\ShopService;
use App\Services\WalletService;
use App\Exceptions\InsufficientOGLCException;
use App\Exceptions\InsufficientBNBException;

class ShopItemController extends Controller
{
    public function __construct(ShopService $shopService)
    {
        $this->shopService = $shopService;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return jsonResponse(ShopItemResource::collection(ShopItem::paginate(100)));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // TODO admin handler
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ShopItem  $shopItem
     * @return \Illuminate\Http\Response
     */
    public function show(ShopItem $shopItem)
    {
        return \jsonResponse(new ShopItemResource($shopItem));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ShopItem  $shopItem
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ShopItem $shopItem)
    {
        // TODO admin handler
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ShopItem  $shopItem
     * @return \Illuminate\Http\Response
     */
    public function destroy(ShopItem $shopItem)
    {
        // TODO check if admin
        // $shopItem->delete();
    }

    /**
     * Buy this item for user for OGLC
     * @param  Request $request [description]
     * @return [type]           [description]
     */
    public function buy(Request $request)
    {
        $user = $request->user();
        $validated = $request->validate([
            'shop_item_id' => ['required', 'integer', 'exists:shop_items,id']
        ]);
        $shopItem = ShopItem::findOrFail($validated['shop_item_id']);
        if ($shopItem->price_oglc != null) {
          try {
            $transaction = $this->shopService->buyForOglc($request->user(), $shopItem);
          } catch (InsufficientOGLCException $e) {
            return \jsonResponse(null, 422, "Insufficient OGLC");
          } catch (Exception $e) {
            return \jsonResponse(null, 422, $e->getMessage());
          }
        } else if ($shopItem->price_bnb != null) {
          try {
            $transaction = $this->shopService->buyForBnb($request->user(), $shopItem);
          } catch (InsufficientBNBException $e) {
            return \jsonResponse(null, 422, "Insufficient BNB");
          } catch (Exception $e) {
            return \jsonResponse(null, 422, $e->getMessage());
          }
        } else {
          return \jsonResponse(null, 422, "This item is not being sold at this time");
        }
        return \jsonResponse(new TransactionResource($transaction));
    }
}
