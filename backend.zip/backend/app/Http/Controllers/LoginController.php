<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Response;
use App\Http\Resources\UserResource;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            "username" => "required|string",
            "password" => "required|string"
        ]);

        if (Auth::attempt([
            "email" => $request->input("username"),
            "password" => $request->input("password")], true)
        ) {
            Auth::loginUsingId(Auth::user()->id, true);
            // Auth::guard('api')->login(Auth::user(), true);
            return jsonResponse(new UserResource(Auth::user()));
        }
        return jsonResponse(null, 401, "Invalid credentials");
    }

    public function logout(Request $request)
    {
        auth('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return jsonResponse();
    }

    public function status(Request $request)
    {
        $user = $request->user();
        return jsonResponse(new UserResource($user));
    }
}
