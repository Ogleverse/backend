<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Resources\UserResource;
use App\Models\Transaction;
use App\Services\GameService;

class BalanceController extends Controller
{
    public function __construct(GameService $gameService)
    {
        $this->gameService = $gameService;
    }

    public function walletToCapital(Request $request)
    {
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01']
        ]);
        if ($validated['amount'] > $request->user()->wallet_balance) {
            return \jsonResponse(null, 422, "Insufficient funds");
        }
        Transaction::create([
            'user_id' => $request->user()->id,
            'amount' => -$validated['amount'],
            'type' => 'wallet_to_capital'
        ]);
        $request->user()->wallet_balance -= $validated['amount'];
        $request->user()->balance += $validated['amount'];
        $request->user()->save();
        return jsonResponse(new UserResource($request->user()));
    }

    public function capitalToWallet(Request $request)
    {
        $game = $this->gameService->getCurrentGame();
        if (!$game || $this->gameService->isGameLocked($game)) {
            return jsonResponse(null, 403, "Genesis is in progress");
        }
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:0.01']
        ]);
        if ($validated['amount'] > $request->user()->balance) {
            return jsonResponse(null, 422, "Insufficient funds");
        }
        Transaction::create([
            'user_id' => $request->user()->id,
            'amount' => $validated['amount'],
            'type' => 'capital_to_wallet'
        ]);
        $request->user()->balance -= $validated['amount'];
        $request->user()->wallet_balance += $validated['amount'];
        $request->user()->save();
        return jsonResponse(new UserResource($request->user()));
    }
}
