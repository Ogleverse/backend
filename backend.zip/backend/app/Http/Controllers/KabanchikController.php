<?php

namespace App\Http\Controllers;

use App\Models\Kabanchik;
use Illuminate\Http\Request;
use App\Services\KabanchikGameService;
use App\Http\Resources\KabanchikResource;
use App\Http\Resources\KabanchikWithTransactionsResource;
use App\Http\Resources\TransactionResource;
use Exception;

class KabanchikController extends Controller
{
    public function __construct(KabanchikGameService $kabanchikGameService)
    {
        $this->kabanchikGameService = $kabanchikGameService;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        return jsonResponse(
            KabanchikWithTransactionsResource::collection(
                Kabanchik::where('user_id', '=', $request->user()->id)->get()
            )
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Buy an egg
     * @param  Request $request
     * @return \Illuminate\Http\Response
     */
    public function buy(Request $request)
    {
        return \jsonResponse(null, 403, "Use POST /shop/buy {shop_item_id} instead");
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Kabanchik  $kabanchik
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, Kabanchik $kabanchik)
    {
        if ($kabanchik->user_id == $request->user()->id) {
          return \jsonResponse(new KabanchikWithTransactionsResource($kabanchik));
        } else {
          return \jsonResponse(new KabanchikResource($kabanchik));
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Kabanchik  $kabanchik
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kabanchik $kabanchik)
    {
        $validated = $request->validate([
            'risk' => ['required', 'number', 'min:0.0', 'max:1.0']
        ]);
        if ($kabanchik->user_id != $request->user()->id) {
            return \jsonResponse(null, 403, "Permission denied");
        }
        $kabanchik->update($validated);
        return \jsonResponse(new KabanchikResource($kabanchik));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Kabanchik  $kabanchik
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kabanchik $kabanchik)
    {
        //
    }

    public function pop(Request $request, int $id)
    {
        $kabanchik = Kabanchik::findOrFail($id);
        if ($kabanchik->user_id != $request->user()->id) {
            return \jsonResponse(null, 403, "Permission denied");
        }
        try {
            $transaction = $this->kabanchikGameService->popKabanchik($kabanchik);
        } catch (Exception $e) {
            return \jsonResponse(null, 422, $e->getMessage());
        }
        return \jsonResponse(new TransactionResource($transaction));
    }
}
