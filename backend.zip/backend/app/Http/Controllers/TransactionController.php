<?php

namespace App\Http\Controllers;

use App\Models\Kabanchik;
use App\Models\Transaction;
use App\Http\Resources\TransactionResource;
use Illuminate\Http\Request;
use Carbon\Carbon;

class TransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $transactions = Transaction::where('user_id', '=', $request->user()->id)
                                   ->whereIn('type', ['bet', 'win'])
                                   ->orderBy('id', 'desc')
                                   ->paginate(100);
        return jsonResponse(TransactionResource::collection($transactions));
    }

    public function showByKabanchik(Request $request, int $id) {
        $kabanchik = Kabanchik::findOrFail($id);
        if ($request->user()->id != $kabanchik->user_id) {
            return \jsonResponse(null, 403, "Permission denied");
        }
        $transactions = Transaction::where('kabanchik_id', '=', $kabanchik->id)
                                   ->whereIn('type', ['bet', 'win'])
                                   ->orderBy('id', 'desc')
                                   ->paginate(400);
        $transactionService = app(\App\Services\TransactionService::class);
        $transactions = $transactionService->getKabanchikTransactions($kabanchik, true);
        return jsonResponse(TransactionResource::collection($transactions));
    }

    public function showChartByKabanchik(Request $request, int $id) {
        $kabanchik = Kabanchik::findOrFail($id);
        if ($request->user()->id != $kabanchik->user_id) {
            return \jsonResponse(null, 403, "Permission denied");
        }
        $transactions = Transaction::where('kabanchik_id', '=', $kabanchik->id)
                                   ->whereIn('type', ['bet', 'win'])
                                   ->orderBy('id', 'desc')
                                   ->paginate(400);
        $transactionService = app(\App\Services\TransactionService::class);
        $transactions = $transactionService->getKabanchikTransactions($kabanchik, true);
        return jsonResponse(TransactionResource::collection($transactions));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Transaction  $transaction
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request, Transaction $transaction)
    {
        if ($transaction->user_id != $request->user()->id) {
            return jsonResponse(nul, 403, "Permission denied");
        }
    }

    public function stats(Request $request)
    {
        $totalBetLastMonth = Transaction::where([
            ['user_id', '=', $request->user()->id],
            ['type', '=', 'bet'],
            ['created_at', '>', Carbon::now()->subMonths(1)]
        ])->sum('amount');
        $totalWonLastMonth = Transaction::where([
            ['user_id', '=', $request->user()->id],
            ['type', '=', 'win'],
            ['created_at', '>', Carbon::now()->subMonths(1)]
        ])->sum('amount');
        $totalSpentLastMonth = Transaction::where([
            ['user_id', '=', $request->user()->id],
            ['type', '=', 'buy'],
            ['created_at', '>', Carbon::now()->subMonths(1)]
        ])->sum('amount');
        $totalEarnedLastMonth = Transaction::where([
            ['user_id', '=', $request->user()->id],
            ['type', '=', 'pop_kabanchik'],
            ['created_at', '>', Carbon::now()->subMonths(1)]
        ])->sum('amount');
        $saldo = $totalBetLastMonth + $totalWonLastMonth;
        return jsonResponse([
            'period' => [
                'from' => Carbon::now()->subMonths(1),
                'till' => Carbon::now()
            ],
            'spent' => -$totalSpentLastMonth,
            'earned' => $totalEarnedLastMonth,
            'bet' => -$totalBetLastMonth,
            'won' => $totalWonLastMonth,
            'saldo' => $saldo
        ]);
    }
}
