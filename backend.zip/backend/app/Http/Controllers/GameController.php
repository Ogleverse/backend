<?php

namespace App\Http\Controllers;

use App\Models\Game;
use App\Models\Kabanchik;
use Illuminate\Http\Request;
use App\Services\GameService;
use App\Services\KabanchikGameService;
use App\Http\Resources\GameResource;
use App\Http\Resources\GameShortResource;
use App\Http\Resources\KabanchikResource;
use App\Http\Resources\TransactionResource;
use \Exception;

class GameController extends Controller
{
    public function __construct(GameService $gameService, KabanchikGameService $kabanchikGameService)
    {
        $this->gameService = $gameService;
        $this->kabanchikGameService = $kabanchikGameService;
        $this->middleware('json.response');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return jsonResponse(
            GameResource::collection(
                Game::orderBy('id', 'desc')->limit(10)->get()
            )
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Game  $game
     * @return \Illuminate\Http\Response
     */
    public function show(Game $game)
    {
        $gameInfo = $this->gameService->getGameInfo($game);
        return jsonResponse(new GameResource([
            'game' => $game,
            'info' => $gameInfo
        ]));
    }

    public function showCurrentGame(Request $request)
    {
        $currentGame = $this->gameService->getCurrentGame();
        if (!$currentGame) {
          return jsonResponse(null, 404, "Not found");
        }
        $gameInfo = $this->gameService->getGameInfo($currentGame);
        // $kabanchik = $this->kabanchikGameService->getKabanchikForUser($request->user());
        $kabanchiks = $this->kabanchikGameService->getKabanchiksForUser($request->user());
        $items = [];
        foreach ($kabanchiks as &$kabanchik) {
            $items = array_merge($items, $this->kabanchikGameService->getItems($kabanchik));
        }
        // $items = $this->kabanchikGameService->getItems($kabanchik);
        return jsonResponse(new GameShortResource([
            'game' => $currentGame,
            'info' => $gameInfo,
            // 'level' => $kabanchik ? $kabanchik->level : -1,
            // 'kabanchik' => $kabanchik ? new KabanchikResource($kabanchik) : null,
            'kabanchiks' => KabanchikResource::collection($kabanchiks),
            'items' => $items
        ]));
    }

    public function join(Request $request)
    {
        $validated = $request->validate([
            'risk' => ['required', 'numeric', 'min:0.0', 'max:1.0'],
            'kabanchik_id' => ['required', 'exists:kabanchiks,id']
        ]);
        try {
            $kabanchik = Kabanchik::find($validated['kabanchik_id']);
            $game = $this->gameService->updateKabanchikRisk(
                $kabanchik,
                $validated['risk']
            );
            $gameInfo = $this->gameService->getGameInfo($game);
            return jsonResponse(new GameResource([
                'game' => $game,
                'info' => $gameInfo
                ]));
        } catch (Exception $e) {
            return jsonResponse(null, 422, $e->getMessage());
        }
    }

    public function getTestCoin(Request $request)
    {
        $walletService = app(\App\Services\WalletService::class);
        $transaction = $walletService->sellForOglc($request->user(), "10");
        $transaction2 = $walletService->sellForBnb($request->user(), "0.0005");
        return jsonResponse($transaction);
    }
}
