<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Actions\Fortify\CreateNewUser;
use App\Http\Resources\UserResource;
use App\Http\Resources\RefUserResource;
use Laravel\Fortify\Rules\Password;

/**
 * Регистрация клиента
 */
class RegistrationController extends Controller
{
    public function __construct()
    {
        $this->middleware('guest');
        $this->middleware('json.response');
    }

    public function register(Request $request)
    {
        $newUser = new CreateNewUser();
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:200'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', 'string', new Password, 'confirmed'],
            'password_confirmation' => ['required', 'string'],
            'skin_id' => ['required', 'integer', 'between:1,6'],
            'ref_user_id' => ['sometimes', 'integer']
        ]);
        if (isset($validated['ref_user_id'])) {
            $refUser = User::find($validated['ref_user_id']);
            if ($refUser) {
                $validated['ref_user_id'] = $refUser->id;
            }
        }
        $user = $newUser->create($validated);

        Auth::login($user, true);

        return jsonResponse(new UserResource($user));
    }

    public function registerRef(Request $request, string $code)
    {
        $user = User::where('ref_code', $code)->first();
        if (!$user) {
            return \jsonResponse(null, 404, "Not found");
        }
        return jsonResponse(new RefUserResource($user));
    }
}
