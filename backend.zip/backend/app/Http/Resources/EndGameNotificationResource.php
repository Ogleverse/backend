<?php

namespace App\Http\Resources;

use App\Http\Resources\GameResource;
use App\Http\Resources\GameEntryResource;
use App\Http\Resources\KabanchikResource;
use App\Http\Resources\RefUserResource;
use App\Models\Game;
use App\Models\GameEntry;
use App\Models\Kabanchik;
use App\Models\KabanchikSkin;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class EndGameNotificationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $game = $this->resource['game'];
        $greediestGameEntry = GameEntry::where([
            ['game_id', '=', $game->id],
        ])->orderBy('result', 'desc')->first();

        if (!$greediestGameEntry) {
            return [
                'event' => 'game_ended',
                'game' => new GameResource(['game' => $game]),
                'topgreed' => null
            ];
        }

        $greediestKabanchik = Kabanchik::find($greediestGameEntry->kabanchik_id);
        $greediestUser = $greediestKabanchik->user;

        $data = [
            'event' => 'game_ended',
            'game' => new GameResource(['game' => $game]),
            'topgreed' => [
                'kabanchik' => new KabanchikResource($greediestKabanchik),
                'user' => new RefUserResource($greediestUser),
                'game_entry' => new GameEntryResource($greediestGameEntry)
            ]
        ];

        return $data;
    }
}
