<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Services\GameService;

class GameResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user = $request->user();
        $gameInfo = $this->resource['info'] ?? [
            'totalBids' => 'n/a',
            'totalPool' => 'n/a'
        ];
        $game = $this->resource['game'];
        $data = [
            'id' => $game->id,
            'can_act_before' => $game->can_act_before,
            'ends_at' => $game->ends_at,
            'is_ended' => $game->is_ended,
            'totalBids' => $game->gameEntries->count(),
            'totalPool' => $game->gameEntries->sum('deposit'),
            // 'entries' => GameEntryResource::collection($game->gameEntries)
        ];
        if ($user) {
            $data['my_balance'] = $user->balance;
            $data['wallet_balance'] = $user->wallet_balance;
            $data['is_joined'] = $game->gameEntries->where('user_id', '=', $user->id)->count() > 0;
        }
        return $data;
    }
}
