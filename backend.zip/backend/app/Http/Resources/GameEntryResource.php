<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class GameEntryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'game_id' => $this->game_id,
            'user_id' => $this->user_id,
            'kabanchik_id' => $this->kabanchik_id,
            'user_name' => $this->user->name,
            'investor_skin_id' => $this->user->skin_id,
            'deposit' => $this->deposit,
            'result' => $this->result,
            'risk' => $this->risk,
            // 'angle' => acos(1/$this->multiplier) / M_PI * 180
        ];
    }
}
