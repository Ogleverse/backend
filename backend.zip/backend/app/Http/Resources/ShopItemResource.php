<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ShopItemResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'type' => $this->type,
            'name' => $this->name,
            'image' => $this->image,
            'description' => $this->description,
            'price_bnb' => $this->price_bnb,
            'discount_price_bnb' => $this->discount_price_bnb,
            'price_oglc' => $this->price_oglc,
            'discount_price_oglc' => $this->discount_price_oglc,
            'data' => $this->data
        ];
    }
}
