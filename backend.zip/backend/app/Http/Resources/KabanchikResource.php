<?php

namespace App\Http\Resources;

use App\Http\Resources\TransactionResource;
use App\Services\KabanchikGameService;
use App\Services\TransactionService;
use Illuminate\Http\Resources\Json\JsonResource;

class KabanchikResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        // $transactionService = new TransactionService();
        // $kabanchikGameService = new KabanchikGameService($transactionService);
        $transactionService = app(TransactionService::class);
        $kabanchikGameService = app(KabanchikGameService::class);
        return [
            'id' => $this->id,
            'level' => $this->level,
            'value' => $this->value,
            'risk' => $this->risk,
            'multiplier' => riskToMultiplier($this->risk),
            'max_value' => $this->value_limit,
            'top_value' => $this->top_value,
            'experience' => $this->experience,
            'next_level_experience' => $this->next_level_experience,
            'is_locked' => $this->is_locked,
            'type' => $this->type,
            'collection' => $this->collection,
            'rarity' => $this->rarity,
            'skin_id' => $this->kabanchik_skin_id,
            'skin' => $this->kabanchikSkin,
        ];
    }
}
