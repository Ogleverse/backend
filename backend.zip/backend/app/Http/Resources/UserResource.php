<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $wsService = app(\App\Services\WebsocketService::class);
        $transactionService = app(\App\Services\TransactionService::class);
        $gameService = app(\App\Services\GameService::class);
        return [
            'id' => $this->id,
            'name' => $this->name,
            // 'balance' => $this->balance,
            // 'wallet_balance' => $this->wallet_balance,
            'balance_oglc' => $this->balance_oglc,
            'balance_bnb' => $this->balance_bnb,
            'multiplier' => $this->multiplier,
            'investor_skin_id' => $this->skin_id,
            'ws_auth_token' => $wsService->getWebsocketAuthToken($this->resource),
            'email_verified_at' => $this->email_verified_at,
            'ref_code' => $this->ref_code,
            'ref_link' => env('APP_URL').'/register/ref/'.$this->ref_code,
            'ref_count' => $gameService->getReferredUsersCountFor($this->resource),
            'pending_transactions' => TransactionResource::collection($transactionService->getPendingTransactions($this->resource)->get())
        ];
    }
}
