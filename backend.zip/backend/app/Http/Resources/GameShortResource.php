<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use App\Services\GameService;

class GameShortResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
      $user = $request->user();
      $gameInfo = $this->resource['info'] ?? [
          'totalBids' => 'n/a',
          'totalPool' => 'n/a'
      ];
      $game = $this->resource['game'];
      return [
          'id' => $game->id,
          'my_balance' => $user->balance,
          'my_wallet_balance' => $user->wallet_balance,
          'my_multiplier' => $user->multiplier,
          'can_act_before' => $game->can_act_before,
          'investor_skin_id' => $user->skin_id,
          'ends_at' => $game->ends_at,
          'is_ended' => $game->is_ended,
          'totalBids' => $gameInfo['totalBids'],
          'totalPool' => $gameInfo['totalPool'],
          'meanBet' => $gameInfo['meanBet'],
          'is_joined' => $user->multiplier > 1,
          // 'level' => $this->resource['level'],
          // 'kabanchik' => $this->resource['kabanchik'],
          'kabanchiks' => KabanchikResource::collection($this->resource['kabanchiks']),
          'items' => $this->resource['items'],
      ];
    }
}
