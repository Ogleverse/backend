<?php

namespace App\Listeners;

use App\Events\TransactionStatusUpdated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use App\Models\Transaction;
use App\Services\ShopService;
use App\Services\WalletService;
use App\Services\WebsocketService;
use App\Services\KabanchikGameService;

class FinalizeUpdatedTransaction
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct(ShopService $shopService, WebsocketService $websocketService, KabanchikGameService $kabanchikGameService)
    {
        $this->shopService = $shopService;
        $this->websocketService = $websocketService;
        $this->kabanchikGameService = $kabanchikGameService;
    }

    /**
     * Handle the event.
     *
     * @param  TransactionStatusUpdated  $event
     * @return void
     */
    public function handle(TransactionStatusUpdated $event)
    {
        $transaction = $event->transaction;
        if ($transaction->status == 'success') {
            if ($transaction->type == 'buy') {
                $this->shopService->finishPurchase($transaction);
            } else if ($transaction->type == 'pop_kabanchik' || $transaction->type == 'sell') {
                $this->kabanchikGameService->finishPoppingKabanchik($transaction);
            }
        }
        if ($transaction->user_id) {
            $this->websocketService->sendMessage($transaction->user_id, [
                'event' => 'transaction_update',
                'transaction' => [
                    'id' => $transaction->id,
                    'type' => $transaction->type,
                    'amount' => $transaction->amount,
                    'currency' => $transaction->currency,
                    'status' => $transaction->status,
                ]
            ]);
        }
    }
}
